//
//  ScoreView.swift
//  hw5
//
//  Created by 陳昰佑 on 2025/12/26.
//

import SwiftUI

struct ScoreView: View {
    let score: Int
    let goHome: () -> Void
    
    @AppStorage("HighScore") var highScore = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "flag.checkered")
                .resizable()
                .scaledToFit()
                .frame(width: 100)
                .foregroundStyle(.blue)
            
            Text("測驗結束")
                .font(.largeTitle)
                .bold()
            
            Text("本次得分")
                .foregroundColor(.gray)
            
            Text("\(score)")
                .font(.system(size: 80, weight: .bold))
                .foregroundStyle(score >= highScore ? .green : .black)
            
            if score >= highScore && score > 0 {
                Text("🎉 新紀錄！ 🎉")
                    .font(.title)
                    .foregroundStyle(.red)
                    .padding()
                    .background(Color.yellow.opacity(0.3))
                    .cornerRadius(10)
            }
            
            Button {
                goHome()
            } label: {
                Text("回到主選單")
                    .font(.title2)
                    .bold()
                    .padding()
                    .frame(width: 200)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(15)
            }
        }
        .onAppear {
            saveScore()
        }
    }
    
    func saveScore() {
        if score > highScore {
            highScore = score
        }
        
        var history = UserDefaults.standard.array(forKey: "ScoreHistory") as? [Int] ?? []
        history.insert(score, at: 0)
        UserDefaults.standard.set(history, forKey: "ScoreHistory")
    }
}
