import SwiftUI

struct Question: Identifiable {
    let id = UUID()
    let text: String
    let options: [String]
    let answer: String
}

let allQuestionsData = [
    Question(
        text: "「流行音樂之王」是指哪位歌手？",
        options: ["Elvis Presley", "Michael Jackson", "Prince", "Madonna"],
        answer: "Michael Jackson"
    ),
    Question(
        text: "鋼琴總共有幾個黑白鍵？",
        options: ["66", "88", "92", "76"],
        answer: "88"
    ),
    Question(
        text: "貝多芬在晚年失去了什麼感官功能？",
        options: ["視力", "嗅覺", "聽力", "味覺"],
        answer: "聽力"
    ),
    Question(
        text: "小提琴通常有幾根弦？",
        options: ["3根", "4根", "5根", "6根"],
        answer: "4根"
    ),
    Question(
        text: "下列哪種樂器屬於「木管樂器」？",
        options: ["小號", "薩克斯風", "長號", "低音號"],
        answer: "薩克斯風"
    ),
    Question(
        text: "著名的《四季》小提琴協奏曲是誰的作品？",
        options: ["巴哈", "韋瓦第", "莫札特", "蕭邦"],
        answer: "韋瓦第"
    ),
    Question(
        text: "五線譜中，高音譜記號又被稱為什麼？",
        options: ["G譜號", "F譜號", "C譜號", "D譜號"],
        answer: "G譜號"
    ),
    Question(
        text: "吉他通常有幾根弦？",
        options: ["4根", "5根", "6根", "7根"],
        answer: "6根"
    ),
    Question(
        text: "哪位歌手被稱為「花蝴蝶」？",
        options: ["Adele", "Mariah Carey", "Beyoncé", "Taylor Swift"],
        answer: "Mariah Carey"
    ),
    Question(
        text: "樂譜上的「f」代表什麼意思？",
        options: ["弱", "強", "慢", "快"],
        answer: "強"
    ),
    Question(
        text: "被譽為「音樂之父」的作曲家是誰？",
        options: ["巴哈", "海頓", "莫札特", "貝多芬"],
        answer: "巴哈"
    ),
    Question(
        text: "管弦樂團中，音域最高的是哪種木管樂器？",
        options: ["長笛", "短笛", "單簧管", "雙簧管"],
        answer: "短笛"
    ),
    Question(
        text: "披頭四樂隊 (The Beatles) 來自哪個國家？",
        options: ["美國", "英國", "澳洲", "加拿大"],
        answer: "英國"
    ),
    Question(
        text: "在樂理中，兩個「半音」相加等於一個什麼？",
        options: ["全音", "倍半音", "三音", "小三度"],
        answer: "全音"
    ),
    Question(
        text: "哪位鋼琴作曲家被稱為「鋼琴詩人」？",
        options: ["李斯特", "蕭邦", "舒曼", "拉赫曼尼諾夫"],
        answer: "蕭邦"
    ),
    Question(
        text: "現代爵士樂發源於美國的哪座城市？",
        options: ["紐約", "芝加哥", "紐奧良", "洛杉磯"],
        answer: "紐奧良"
    ),
    Question(
        text: "樂譜上的「p」代表什麼意思？",
        options: ["弱", "強", "中庸", "極強"],
        answer: "弱"
    ),
    Question(
        text: "下列哪件樂器不屬於「銅管樂器」？",
        options: ["法國號", "長號", "小號", "長笛"],
        answer: "長笛"
    ),
    Question(
        text: "著名的《藍色多瑙河》圓舞曲是誰的作品？",
        options: ["小約翰·史特勞斯", "老約翰·史特勞斯", "馬勒", "布拉姆斯"],
        answer: "小約翰·史特勞斯"
    ),
    Question(
        text: "由四個人組成的室內樂演出，最常見的編制是？",
        options: ["鋼琴四重奏", "弦樂四重奏", "木管四重奏", "銅管四重奏"],
        answer: "弦樂四重奏"
    ),
]



struct ContentView: View {
    @State private var currentState: Int = 0
    @State private var finalScore = 0
    
    var body: some View {
        ZStack {
            
            if currentState == 0 {
                Color.orange.opacity(0.1).ignoresSafeArea()
            } else if currentState == 1 {
                Color.indigo.opacity(0.1).ignoresSafeArea()
            } else if currentState == 2 {
                Color.blue.opacity(0.1).ignoresSafeArea()
            }


            if currentState == 0 {
                MenuView(startGame: {
                    withAnimation { currentState = 1 }
                })
                .transition(.scale)
            } else if currentState == 1 {
                GameView(endGame: { score in
                    finalScore = score
                    withAnimation { currentState = 2 }
                })
                .transition(.opacity)
            } else if currentState == 2 {
                ScoreView(
                    score: finalScore,
                    goHome: {
                        withAnimation { currentState = 0 }
                    }
                )
                .transition(.move(edge: .bottom))
            }
        }
    }
}

#Preview {
    ContentView()
}
