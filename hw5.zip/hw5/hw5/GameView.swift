//
//  GameView.swift
//  hw5
//
//  Created by 陳昰佑 on 2025/12/26.
//

import SwiftUI


struct GameView: View {
    let endGame: (Int) -> Void
    
    @State private var currentQuestions: [Question] = []
    @State private var index = 0
    @State private var score = 0
    @State private var streak = 0
    @State private var shuffledOptions: [String] = []
    
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        VStack {
            if !currentQuestions.isEmpty {
                HStack {
                    Text("第 \(index + 1) / 10 題")
                    Spacer()
                    if streak >= 2 {
                        Text("🔥連對: \(streak)")
                            .foregroundStyle(.red).bold()
                            .transition(.scale)
                    }
                    Spacer()
                    Text("分數: \(score)").bold()
                }
                .padding().font(.title3)
                
                Spacer()
                
                Text(currentQuestions[index].text)
                    .font(.title)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(20)
                    .padding()
                    .shadow(radius: 5)
                    .id(index)
                    .transition(.asymmetric(insertion: .move(edge: .trailing), removal: .move(edge: .leading)))
                
                Spacer()
                
                VStack(spacing: 15) {
                    ForEach(shuffledOptions, id: \.self) { option in
                        Button {
                            checkAnswer(userChoice: option)
                        } label: {
                            Text(option)
                                .font(.title3)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                    }
                }
                .padding()
            }
        }
        .onAppear {
            setupGame()
        }
        .alert("答錯了！", isPresented: $showAlert) {
            Button("下一題") { nextQuestion() }
        } message: {
            Text(alertMessage)
        }
    }
    
    func setupGame() {
        currentQuestions = Array(allQuestionsData.shuffled().prefix(10))
        index = 0
        score = 0
        streak = 0
        listOptions()
    }
    
    func listOptions() {
        if index < currentQuestions.count {
            shuffledOptions = currentQuestions[index].options.shuffled()
        }
    }
    
    func checkAnswer(userChoice: String) {
        let correctAns = currentQuestions[index].answer
        
        if userChoice == correctAns {
            // 答對
            triggerHaptic(isSuccess: true)
            streak += 1
            if streak >= 3 { score += 30 } else { score += 10 }
            nextQuestion()
        } else {
            // 答錯
            triggerHaptic(isSuccess: false)
            streak = 0
            score -= 10
            alertMessage = "正確答案是：\(correctAns)\n扣 10 分"
            showAlert = true
        }
    }
    
    func nextQuestion() {
        if index < currentQuestions.count - 1 {
            withAnimation {
                index += 1
                listOptions()
            }
        } else {
            endGame(score)
        }
    }
    
    func triggerHaptic(isSuccess: Bool) {
        let generator = UINotificationFeedbackGenerator()
        generator.prepare()
        generator.notificationOccurred(isSuccess ? .success : .error)
    }
}
