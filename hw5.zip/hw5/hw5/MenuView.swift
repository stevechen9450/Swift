//
//  MenuView.swift
//  hw5
//
//  Created by 陳昰佑 on 2025/12/26.
//
import SwiftUI

struct MenuView: View {
    let startGame: () -> Void
    
    @AppStorage("HighScore") var highScore = 0
    @State private var scoreHistory: [Int] = []
    
    var body: some View {
        VStack(spacing: 20) {
            Text("🎵 音樂知識王 🎵")
                .font(.system(size: 40, weight: .heavy))
                .foregroundStyle(.purple)
            
            VStack {
                Text("🏆 最高分紀錄")
                    .font(.headline)
                    .foregroundColor(.gray)
                Text("\(highScore)")
                    .font(.system(size: 50, weight: .bold))
                    .foregroundColor(.orange)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(15)
            .shadow(radius: 3)
            
            Button {
                startGame() 
            } label: {
                Text("開始挑戰")
                    .font(.title2)
                    .bold()
                    .frame(width: 200, height: 60)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(30)
                    .shadow(radius: 5)
            }
            .padding(.bottom, 20)
            
            Text("📜 近期歷史紀錄")
                .font(.headline)
                .padding(.top)
            
            List {
                ForEach(scoreHistory.indices, id: \.self) { i in
                    Text("第 \(i + 1) 回：\(scoreHistory[i]) 分")
                }
            }
            .listStyle(.plain)
            .frame(height: 200)
            .cornerRadius(10)
            .padding(.horizontal)
        }
        .onAppear {
            loadHistory()
        }
    }
    
    func loadHistory() {
        if let savedHistory = UserDefaults.standard.array(forKey: "ScoreHistory") as? [Int] {
            scoreHistory = savedHistory
        }
    }
}
