//
//  hw5App.swift
//  hw5
//
//  Created by 陳昰佑 on 2025/12/24.
//

import SwiftUI

@main
struct hw5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
