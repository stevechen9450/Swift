//
//  hw5Tests.swift
//  hw5Tests
//
//  Created by 陳昰佑 on 2025/12/24.
//

import Testing
@testable import hw5

struct hw5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
