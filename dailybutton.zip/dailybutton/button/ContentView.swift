//
//
//

import SwiftUI

struct WaterDispenserView: View {
    @State private var isLocked = true  // 預設鎖定
    @State private var waterFlowHeight: CGFloat = 0  // 水流高度
    @State private var waterColor: Color = .clear  // 水的顏色
    @State private var message = "待機中"
    @State private var lockTimer: Timer? // 自動上鎖

    var body: some View {
        ZStack {

            VStack(spacing: 20) {
                Text("飲水機")
                    .font(.largeTitle)
                    .bold()
                    .foregroundStyle(.black)


                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(
                            LinearGradient(
                                colors: [.gray, .white, .gray],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: 280, height: 400)
                        .shadow(radius: 10)

                    VStack {
                        ZStack {
                            Rectangle()
                                .fill(.black)
                                .frame(height: 80)
                                .padding(.top, 20)
                                .offset(y: -20)

                            HStack {
                                Text(message)
                                    .font(.title2)
                                    .foregroundStyle(.green)
                                    .bold()
                                    .offset(y: -20)
                                
                                Spacer()

                                Image(
                                    systemName: isLocked
                                        ? "lock.fill" : "lock.open.fill"
                                )
                                .foregroundStyle(isLocked ? .red : .green)
                                .font(.title)
                                .offset(y: -20)
                            }
                            .padding(.horizontal, 40)
                            .padding(.top, 20)
                        }

                        Spacer()

                        ZStack(alignment: .top) {
                            Rectangle()
                                .fill(.gray)
                                .frame(width: 40, height: 20)

                            Rectangle()
                                .fill(waterColor)
                                .frame(width: 15, height: waterFlowHeight)
                                .opacity(0.8)
                        }

                        // 杯子
                        ZStack {
                            Path { path in
                                path.move(to: CGPoint(x: 0, y: 0))
                                path.addLine(to: CGPoint(x: 10, y: 100))
                                path.addLine(to: CGPoint(x: 90, y: 100))
                                path.addLine(to: CGPoint(x: 100, y: 0))
                            }
                            .fill(.blue.opacity(0.1))
                            .stroke(.blue, lineWidth: 2)
                            .frame(width: 100, height: 100)

                            if waterFlowHeight > 50 {
                                Rectangle()
                                    .fill(waterColor)
                                    .frame(width: 70, height: 60)
                                    .offset(y: 20)
                                    .transition(.opacity)
                            }
                        }
                        .padding(.bottom, 20)
                    }
                }

                // 控制面板按鈕
                HStack(spacing: 20) {
                    // 解鎖鈕
                    Button {
                        toggleLock()
                    } label: {
                        ControlButton(
                            title: "解鎖",
                            color: .orange,
                            icon: isLocked ? "lock" : "lock.open"
                        )
                    }

                    // 熱水
                    Button {
                        dispenseWater(type: .hot)
                    } label: {
                        ControlButton(
                            title: "熱水",
                            color: .red,
                            icon: "thermometer.sun"
                        )
                    }

                    // 溫水
                    Button {
                        dispenseWater(type: .warm)
                    } label: {
                        ControlButton(title: "溫水", color: .green, icon: "drop")
                    }
                }
            }
        }
    }

    // 如何解鎖
    func toggleLock() {
        withAnimation {
            isLocked.toggle()
        }

        if !isLocked {
            message = "已解鎖"
            // 3秒後自動上鎖
            lockTimer?.invalidate()
            lockTimer = Timer.scheduledTimer(
                withTimeInterval: 3.0,
                repeats: false
            ) { _ in
                withAnimation {
                    isLocked = true
                    message = "自動上鎖"
                }
            }
        } else {
            message = "已鎖定"
        }
    }

    // 如何出水
    func dispenseWater(type: WaterType) {
        // 如果是熱水且鎖定中，就要先解鎖
        if type == .hot && isLocked {
            message = "請先解鎖！"
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
            return
        }

        // 正常出水
        message = "出水中..."
        waterColor = type.color

        // 重置自動上鎖計時器
        if !isLocked {
            lockTimer?.invalidate()
        }

        // 水流下來
        withAnimation(.easeOut(duration: 0.2)) {
            waterFlowHeight = 140
        }

        // 1.5秒後停止
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation(.easeIn(duration: 0.2)) {
                waterFlowHeight = 0
            }
            message = "完成"

            // 如果是解鎖狀態，用完後自動上鎖
            if !isLocked {
                withAnimation {
                    isLocked = true
                }
            }
        }
    }

    // 定義水的類型與顏色
    enum WaterType {
        case hot, warm
        var color: Color {
            switch self {
            case .hot: return .red
            case .warm: return .cyan
            }
        }
    }
}

// 按鈕設計
struct ControlButton: View {
    let title: String
    let color: Color
    let icon: String
    var body: some View {
        VStack {
            Circle()
                .fill(color.opacity(0.2))
                .frame(width: 70, height: 70)
                .overlay(
                    Image(systemName: icon)
                        .font(.title)
                        .foregroundStyle(color)
                )
                .overlay(Circle().stroke(color, lineWidth: 2))

            Text(title).font(.caption).bold()
        }
    }
}

#Preview {
    WaterDispenserView()
}
