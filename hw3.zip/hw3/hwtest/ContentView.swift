import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.indigo.opacity(0.8), Color.pink.opacity(0.6)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 20) {
                    GradientHeaderView()
                    PosterView()
                    IntroductionView()
                    SynopsisView()
                    MusicHighlightsView()
                    ProductionSeriesView()
                    MainCharacters()
                }
                .padding()
            }
        }
    }
}

// MARK: 標題
struct GradientHeaderView: View {
    var body: some View {
        ZStack(alignment: .bottomLeading) {

            
            VStack(alignment: .leading, spacing: 6) {
                Text("Sound! Euphonium")
                    .font(.system(size: 34, weight: .bold, design: .default))
                    .foregroundStyle(.white)

                HStack(spacing: 8) {
                    Image(systemName: "music.note.list")
                        .foregroundStyle(.white)
                    Text("北宇治高校吹奏楽部")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.95))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.black.opacity(0.2))
            }
            .padding(16)
        }
    }
}

// MARK: 海報
struct PosterView: View {
    var body: some View {
        Image("euphoPoster")
            .resizable()
            .aspectRatio(640.0/950.0, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .border(.yellow, width: 3)
            .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}

// MARK: 作品介紹
struct IntroductionView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: "book")
                    .font(.largeTitle)
                    .foregroundStyle(.black)

                Text("作品簡介與核心")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }

            Text("「吹響吧！上低音號」改編自武田綾乃的小說，由京都動畫製作。作品以北宇治高中吹奏樂社為舞台，描繪主角黃前久美子與社員們在努力前往全國大賽過程中的青春群像劇、個人成長與複雜的人際關係。")
            .font(.body)
            .lineSpacing(5)
            .foregroundStyle(.black)
            
            
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}

// MARK: 主角群
struct SynopsisView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: "figure.walk.motion")
                    .font(.largeTitle)
                    .foregroundStyle(.black)
                
                Text("故事核心與成長路線")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }
            
            Text("「吹響吧！」系列的核心主軸是「通往全國大賽的競賽之路」與「個人對音樂的執著與友情」。故事跟隨黃前久美子從一年級新生到三年級部長的成長軌跡，每一次比賽都伴隨著嚴峻的社團內鬥與複雜的夥伴情感。")
                .font(.body)
                .lineSpacing(5)
                .foregroundStyle(.black)
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}

struct RolePill: View {
    let name: String
    let instrument: String
    let color: Color
    
    var body: some View {
        HStack {
            Text(name)
                .font(.subheadline)
                .fontWeight(.bold)
            Text(instrument)
                .font(.caption)
                .padding(.horizontal, 6)
                .background(color.opacity(0.2))
                .clipShape(Capsule())
        }
        .padding(.vertical, 4)
    }
}

// MARK: 音樂
struct MusicHighlightsView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: "music.note")
                    .font(.largeTitle)
                    .foregroundStyle(.black)
                Text("必聽精選")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }
            
            VStack(alignment: .leading, spacing: 12) {
                MusicItemView(
                    title: "Dream Solister (S1 OP)",
                    composer: "作詞：畑亜貴 / 作曲：加藤達也",
                    description: "系列最經典片頭曲！充滿青春、希望與夢想的力量，是吹響系列精神的完美展現，絕對值得一再回味！",
                    color: .red
                )
                
                MusicItemView(
                    title: "三日月の舞",
                    composer: "松田彬人",
                    description: "北宇治在關西大賽上的自由曲。氣勢磅礴，特別是麗奈高音小號與久美子上低音號的關鍵合奏片段，令人動容。",
                    color: .indigo
                )
                
                MusicItemView(
                    title: "普羅旺斯之風 (風のプロヴァンス)",
                    composer: "田坂直樹",
                    description: "北宇治挑戰全國大賽的自由曲，充滿法國風情的優雅與宏大。代表了吹奏部對全國金賞的極致渴望。",
                    color: .orange
                )
            }
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.1), radius: 5, y: 3)
    }
}

struct MusicItemView: View {
    let title: String
    let composer: String
    let description: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundStyle(color)
            
            Text(composer)
                .font(.footnote)
                .foregroundStyle(.black)
            
            Text(description)
                .font(.callout)
                .lineLimit(nil)
                .foregroundStyle(.black)
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .background(color.opacity(0.07))
        .cornerRadius(8)
    }
}

// MARK: 作品系列時間線
struct ProductionSeriesView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "music.pages.fill")
                    .font(.largeTitle)
                    .foregroundStyle(.black)

                Text("系列作品")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }
            .padding(.leading, 10)
            .padding(.bottom, 5)

            VStack(spacing: 15) {
                SeriesItemView(
                    year: "2015",
                    title: "第一季：歡迎加入北宇治",
                    type: "TV動畫 S1 (起點)",
                    color: .blue,
                )
                
                SeriesItemView(
                    year: "2016",
                    title: "第二季：通往全國的旅程",
                    type: "TV動畫 S2",
                    color: .purple,
                )
                
                SeriesItemView(
                    year: "2018",
                    title: "莉茲與青鳥",
                    type: "劇場版 (獨特番外篇)",
                    color: .cyan,
                )
                
                SeriesItemView(
                    year: "2019",
                    title: "誓言的終章",
                    type: "劇場版 (久美子二年級)",
                    color: .orange,
                )
                
                SeriesItemView(
                    year: "2023",
                    title: "合奏比賽",
                    type: "OVA/中篇",
                    color: .pink,
                )
                
                SeriesItemView(
                    year: "2024",
                    title: "第三季：我們的音色",
                    type: "TV動畫 S3 (久美子三年級)",
                    color: .red,
                )
            }
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}

struct SeriesItemView: View {
    let year: String
    let title: String
    let type: String
    let color: Color
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            VStack(spacing: 0) {
                Text(year)
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
                    .frame(height: 15)
                
                Circle()
                    .fill(color)
                    .frame(width: 14, height: 14)
            }
            .frame(width: 50, alignment: .top)

            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundStyle(.black)
                
            
            }
            Spacer()
        }
    }
}


// MARK: 角色
struct CharacterView: View {
    var characterName: String
    var description: String
    var instrumentIcon: String

    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            ZStack {
                Circle()
                    .fill(Color.mint.opacity(0.2))
                    .frame(width: 70, height: 70)

                Image(instrumentIcon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text(characterName)
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)

                Text(description)
                    .font(.callout)
                    .foregroundStyle(.black)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.9))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.08), radius: 6, y: 4)
    }
}

// MARK: 三位主角
struct MainCharacters: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("主角群的夥伴們")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.leading, 10)
            
            VStack(spacing: 12) {
                CharacterView(
                    characterName: "黃前久美子",
                    description: "主角。北宇治高中吹奏樂社上低音號（Euphonium）演奏者，從不說出口的內心話是本篇一大看點。",
                    instrumentIcon: "KuBeGXl.jpg"
                )
                CharacterView(
                    characterName: "高坂麗奈",
                    description: "小號（Trumpet）演奏者，對音樂有絕對的熱情與自信，目標是成為特別的人。",
                    instrumentIcon: "aoowgmk"
                )
                CharacterView(
                    characterName: "加藤葉月",
                    description: "社團的初心者，負責吹奏低音號（Tuba），是久美子身邊最熱情的支持者。",
                    instrumentIcon: "04_jk"
                )
            }
        }
    }
}


#Preview {
    ContentView()
}

