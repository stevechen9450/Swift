import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.indigo.opacity(0.8), Color.pink.opacity(0.6)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 20) {
                    HeaderView()
                    PosterView()
                    IntroductionView()
                    StoryView()
                    MusicHighlightsView()
                    ProductionSeriesView()
                    MainCharacters()
                }
                .padding()
            }
        }
    }
}


#Preview {
    ContentView()
}

