//
//  HeaderView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct HeaderView: View {
    var body: some View {
        ZStack(alignment: .bottomLeading) {

            
            VStack(alignment: .leading, spacing: 6) {
                Text("Sound! Euphonium")
                    .font(.system(size: 34, weight: .bold, design: .default))
                    .foregroundStyle(.white)

                HStack(spacing: 8) {
                    Image(systemName: "music.note.list")
                        .foregroundStyle(.white)
                    Text("北宇治高校吹奏楽部")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.95))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.black.opacity(0.2))
            }
            .padding(16)
        }
    }
}
