//
//  MusicHighlightsView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct MusicHighlightsView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: "music.note")
                    .font(.largeTitle)
                    .foregroundStyle(.black)
                Text("必聽精選")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }
            
            VStack(alignment: .leading, spacing: 12) {
                MusicItemView(
                    title: "Dream Solister (S1 OP)",
                    composer: "作詞：畑亜貴 / 作曲：加藤達也",
                    description: "系列最經典片頭曲！充滿青春、希望與夢想的力量，是吹響系列精神的完美展現，絕對值得一再回味！",
                    color: .red
                )
                
                MusicItemView(
                    title: "三日月の舞",
                    composer: "松田彬人",
                    description: "北宇治在關西大賽上的自由曲。氣勢磅礴，特別是麗奈高音小號與久美子上低音號的關鍵合奏片段，令人動容。",
                    color: .indigo
                )
                
                MusicItemView(
                    title: "普羅旺斯之風 (風のプロヴァンス)",
                    composer: "田坂直樹",
                    description: "北宇治挑戰全國大賽的自由曲，充滿法國風情的優雅與宏大。代表了吹奏部對全國金賞的極致渴望。",
                    color: .orange
                )
            }
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.1), radius: 5, y: 3)
    }
}

struct MusicItemView: View {
    let title: String
    let composer: String
    let description: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundStyle(color)
            
            Text(composer)
                .font(.footnote)
                .foregroundStyle(.black)
            
            Text(description)
                .font(.callout)
                .lineLimit(nil)
                .foregroundStyle(.black)
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .background(color.opacity(0.07))
        .cornerRadius(8)
    }
}
