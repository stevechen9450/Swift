//
//  hwtestApp.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/10/2.
//

import SwiftUI

@main
struct hwtestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
