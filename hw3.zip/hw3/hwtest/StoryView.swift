//
//  StoryView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct StoryView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: "figure.walk.motion")
                    .font(.largeTitle)
                    .foregroundStyle(.black)
                
                Text("故事核心與成長路線")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }
            
            Text("「吹響吧！」系列的核心主軸是「通往全國大賽的競賽之路」與「個人對音樂的執著與友情」。故事跟隨黃前久美子從一年級新生到三年級部長的成長軌跡，每一次比賽都伴隨著嚴峻的社團內鬥與複雜的夥伴情感。")
                .font(.body)
                .lineSpacing(5)
                .foregroundStyle(.black)
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}
