//
//  IntroductionView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct IntroductionView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Image(systemName: "book")
                    .font(.largeTitle)
                    .foregroundStyle(.black)

                Text("作品簡介與核心")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }

            Text("「吹響吧！上低音號」改編自武田綾乃的小說，由京都動畫製作。作品以北宇治高中吹奏樂社為舞台，描繪主角黃前久美子與社員們在努力前往全國大賽過程中的青春群像劇、個人成長與複雜的人際關係。")
            .font(.body)
            .lineSpacing(5)
            .foregroundStyle(.black)
            
            
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}
