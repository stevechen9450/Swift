//
//  PosterView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct PosterView: View {
    var body: some View {
        Image("euphoPoster")
            .resizable()
            .aspectRatio(640.0/950.0, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .border(.yellow, width: 3)
            .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}
