//
//  ProductionSeriesView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct ProductionSeriesView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Image(systemName: "music.pages.fill")
                    .font(.largeTitle)
                    .foregroundStyle(.black)

                Text("系列作品")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
            }
            .padding(.leading, 10)
            .padding(.bottom, 5)

            VStack(spacing: 15) {
                SeriesItemView(
                    year: "2015",
                    title: "第一季：歡迎加入北宇治",
                    type: "TV動畫 S1 (起點)",
                    color: .blue,
                )
                
                SeriesItemView(
                    year: "2016",
                    title: "第二季：通往全國的旅程",
                    type: "TV動畫 S2",
                    color: .purple,
                )
                
                SeriesItemView(
                    year: "2018",
                    title: "莉茲與青鳥",
                    type: "劇場版 (獨特番外篇)",
                    color: .cyan,
                )
                
                SeriesItemView(
                    year: "2019",
                    title: "誓言的終章",
                    type: "劇場版 (久美子二年級)",
                    color: .orange,
                )
                
                SeriesItemView(
                    year: "2023",
                    title: "合奏比賽",
                    type: "OVA/中篇",
                    color: .pink,
                )
                
                SeriesItemView(
                    year: "2024",
                    title: "第三季：我們的音色",
                    type: "TV動畫 S3 (久美子三年級)",
                    color: .red,
                )
            }
        }
        .padding()
        .background(Color.white.opacity(0.95))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.12), radius: 8, y: 5)
    }
}

struct SeriesItemView: View {
    let year: String
    let title: String
    let type: String
    let color: Color
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            VStack(spacing: 0) {
                Text(year)
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
                    .frame(height: 15)
                
                Circle()
                    .fill(color)
                    .frame(width: 14, height: 14)
            }
            .frame(width: 50, alignment: .top)

            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundStyle(.black)
                
            
            }
            Spacer()
        }
    }
}
