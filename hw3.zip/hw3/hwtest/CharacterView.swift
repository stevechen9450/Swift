//
//  CharacterView.swift
//  hwtest
//
//  Created by 陳昰佑 on 2025/11/14.
//
import SwiftUI

struct CharacterView: View {
    var characterName: String
    var description: String
    var instrumentIcon: String

    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            ZStack {
                Circle()
                    .fill(Color.mint.opacity(0.2))
                    .frame(width: 70, height: 70)

                Image(instrumentIcon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text(characterName)
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)

                Text(description)
                    .font(.callout)
                    .foregroundStyle(.black)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.9))
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.08), radius: 6, y: 4)
    }
}


struct MainCharacters: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("主角群的夥伴們")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.leading, 10)
            
            VStack(spacing: 12) {
                CharacterView(
                    characterName: "黃前久美子",
                    description: "主角。北宇治高中吹奏樂社上低音號（Euphonium）演奏者，從不說出口的內心話是本篇一大看點。",
                    instrumentIcon: "KuBeGXl.jpg"
                )
                CharacterView(
                    characterName: "高坂麗奈",
                    description: "小號（Trumpet）演奏者，對音樂有絕對的熱情與自信，目標是成為特別的人。",
                    instrumentIcon: "aoowgmk"
                )
                CharacterView(
                    characterName: "加藤葉月",
                    description: "社團的初心者，負責吹奏低音號（Tuba），是久美子身邊最熱情的支持者。",
                    instrumentIcon: "04_jk"
                )
            }
        }
    }
}
