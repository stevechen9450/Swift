//
//  hw4Tests.swift
//  hw4Tests
//
//  Created by 陳昰佑 on 2025/12/23.
//

import Testing
@testable import hw4

struct hw4Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
