//
//  AboutView.swift
//  hw4
//
//

import Foundation
import SwiftUI

struct AboutView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                BackgroundView()
                
                VStack(spacing: 30) {
                    Image(systemName: "person.crop.circle.badge.checkmark")
                        .font(.system(size: 80))
                        .foregroundColor(.indigo)
                    
                    Text("App創作者")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text("陳昰佑")
                        .font(.title)
                        .bold()
                    
                    List {
                        Section(header: Text("關於我")) {
                            Label("NTU圖資大一", systemImage: "arrow.right.circle")
                            Label("六年的管樂生涯🎺", systemImage: "music.note")
                            Label("喜歡各類音樂🎵", systemImage: "music.note")
                            Label("喜歡中文文學作品", systemImage: "book.closed")
                        }
                        .listRowBackground(Rectangle().fill(.ultraThinMaterial))
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("關於")
        }
    }
}

#Preview {
    AboutView()
}
