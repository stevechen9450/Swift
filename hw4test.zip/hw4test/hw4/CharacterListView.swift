//
//  CharacterListView.swift
//  hw4
//
//
import Foundation
import SwiftUI

struct CharacterListView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                BackgroundView()
                
                List(characters) { char in
                    NavigationLink(destination: CharacterDetailView(character: char)) {
                        HStack {
                            
                            Image(char.imageName)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 50, height: 50)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(char.themeColor.opacity(0.5), lineWidth: 2))
                            
                            VStack(alignment: .leading) {
                                Text(char.name).font(.headline)
                                Text(char.instrument).font(.subheadline).foregroundColor(.secondary)
                            }
                        }
                    }
                    .listRowBackground(Rectangle().fill(.ultraThinMaterial))
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("主要角色")
        }
    }
}

struct CharacterDetailView: View {
    let character: Character
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Image(character.imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding(.horizontal)
                    .padding(.top)
                
                VStack(alignment: .leading, spacing: 10) {
                    Text(character.name)
                        .font(.system(size: 34, weight: .bold))
                    
                    Text("樂器：\(character.instrument)")
                        .font(.title3)
                    Text("身份／聲部：\(character.role)")
                        .font(.title3)
                    
                    Divider()
                    
                    Text("人物介紹")
                        .font(.headline)
                    
                    Text(character.description)
                        .lineSpacing(8)
                }
                .padding()
                .background(Material.thin)
                .cornerRadius(20)
                .padding()
            }
        }
        .background(Color.clear)
        .navigationTitle(character.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    CharacterListView()
}
