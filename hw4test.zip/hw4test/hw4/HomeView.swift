//
//  HomeView.swift
//  hw4
//
//

import Foundation
import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                BackgroundView()
                
                List {
                    Section {
                        VStack(alignment: .leading) {
                            Image("poster")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                .shadow(radius: 10)
                                .padding(.bottom)
                            
                            Text("吹響吧！上低音號")
                                .font(.largeTitle)
                                .fontWeight(.black)
                            
                            Text("北宇治高中吹奏樂部的熱血故事")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical)
                        .listRowBackground(Color.clear)
                    }
                    .listRowSeparator(.hidden)

                    
                    Section(header: Text("必聽曲目").font(.title2).bold().foregroundColor(.primary)) {
                        ForEach(music) { track in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(track.title).font(.headline)
                                    Text(track.composer).font(.caption).foregroundColor(.secondary)
                                }
                                Spacer()
                                Text(track.tag)
                                    .font(.system(size: 10, weight: .bold))
                                    .padding(5)
                                    .background(Color.indigo.opacity(0.1))
                                    .foregroundColor(.indigo)
                                    .cornerRadius(5)
                            }
                            .listRowBackground(Rectangle().fill(.ultraThinMaterial))
                        }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("首頁")
        }
    }
}
#Preview {
    HomeView()
}
