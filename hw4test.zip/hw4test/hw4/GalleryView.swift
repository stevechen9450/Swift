//
//  GalleryView.swift
//  hw4
//
//

import Foundation
import SwiftUI


struct GalleryView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                BackgroundView()
                
                VStack {
                    TabView {
                        ForEach(gallery, id: \.title) { item in
                            VStack {
                                ZStack(alignment: .bottomLeading) {
                                    Image(item.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(20)
                                        .font(.system(size: 80))
                                        .foregroundColor(.white)
                                    
                                    VStack(alignment: .leading) {
                                        Text(item.title)
                                            .font(.title)
                                            .bold()
                                        Text(item.caption)
                                    }
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(Material.ultraThin))
                                }
                            }
                            .padding()
                        }
                    }
                    .tabViewStyle(.page)
                    .indexViewStyle(.page(backgroundDisplayMode: .always))
                }
            }
            .navigationTitle("相簿")
        }
    }
}
extension Color {
    static let slate200 = Color(red: 0.89, green: 0.91, blue: 0.94)
}

#Preview {
    GalleryView()
}

