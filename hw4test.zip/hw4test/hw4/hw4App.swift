//
//  hw4App.swift
//  hw4
//

import SwiftUI

@main
struct hw4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
