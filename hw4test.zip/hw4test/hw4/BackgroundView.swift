//
//  BackgroundView.swift
//  hw4
//


import SwiftUI

struct BackgroundView: View {

    let sunsetOrange = Color(red: 1.0, green: 0.6, blue: 0.45)
    let deepPink = Color(red: 0.85, green: 0.3, blue: 0.4)
    let twilightIndigo = Color(red: 0.3, green: 0.25, blue: 0.5)
    let brassGold = Color(red: 1.0, green: 0.85, blue: 0.4)
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [sunsetOrange, deepPink, twilightIndigo]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            GeometryReader { geometry in
                ZStack {
                    Circle()
                        .fill(brassGold.opacity(0.2))
                        .blur(radius: 60)
                        .frame(width: 350, height: 350)
                        .position(x: 80, y: 150)
                    
                    Circle()
                        .fill(Color.blue.opacity(0.15))
                        .blur(radius: 50)
                        .frame(width: 250, height: 250)
                        .position(x: geometry.size.width - 100, y: geometry.size.height - 200)
                }
            }
            .ignoresSafeArea()
            
            Color.clear
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
                .opacity(0.3)
        }
    }
}
