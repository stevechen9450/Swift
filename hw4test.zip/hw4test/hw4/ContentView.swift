//
//  ContentView.swift
//  hw4
//
//

import Foundation
import SwiftUI

struct Character: Identifiable {
    let id = UUID()
    let name: String
    let instrument: String
    let description: String
    let imageName: String
    let themeColor: Color
    let role: String
}

struct Gallery: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
    let caption: String
}

struct Music: Identifiable {
    let id = UUID()
    let title: String
    let composer: String
    let description: String
    let tag: String
}

let characters = [
    Character(
        name: "黃前久美子",
        instrument: "上低音號",
        description:
            "北宇治高中吹奏樂部部長。初中時曾因一句話傷害了麗奈，內心一直耿耿於懷。性格隨和但關鍵時刻極具領導力，擁有溫暖、易親近的特質。",
        imageName: "euph",
        themeColor: .orange,
        role: "部長 / 低音組"
    ),
    Character(
        name: "高坂麗奈",
        instrument: "小號",
        description:
            "實力極佳的吹奏者。追求「獨一無二」因而孤傲，對音樂有著近乎完美的嚴苛要求。與久美子建立了超越友誼的深刻羈絆，是樂團前進的靈魂。",
        imageName: "trumpet",
        themeColor: .red,
        role: "首席 / 小號組"
    ),
    Character(
        name: "加藤葉月",
        instrument: "低音號",
        description:
            "性格開朗的運動女孩，高中才開始接觸吹奏樂。雖然一度因練習挫折而落淚，但始終保持陽光般的笑容，是低音組最堅強的後盾。",
        imageName: "tuba",
        themeColor: .green,
        role: "初學者 / 低音組"
    ),
    Character(
        name: "川島綠輝",
        instrument: "低音大提琴",
        description: "身材嬌小卻對音樂充滿熱情，曾就讀音樂名校，對低音大提琴有著無比的熱情。",
        imageName: "川島 緑輝",
        themeColor: .blue,
        role: "資深樂手 / 低音組"
    ),
]

let gallery = [
    Gallery(
        title: "全國大賽之路",
        imageName: "competition",
        caption: "全神貫注地投入練習，在音樂教室練習的每份努力，都是為了在全國賽舞台上大放異彩。"
    ),
    Gallery(
        title: "大吉山之夜",
        imageName: "sparkles",
        caption: "在繁星閃爍的山林中，久美子與麗奈許下了承諾，兩人的旋律線與故事就此交織。"
    ),
    Gallery(
        title: "合奏的奇蹟",
        imageName: "ensemble",
        caption: "不同音色的交融，從衝突到和諧。北宇治高中吹奏樂部，即將吹響決賽的號角。"
    ),
]

let music = [
    Music(
        title: "Dream Solister",
        composer: "唐澤美帆",
        description: "第一季片頭曲",
        tag: "OP"
    ),
    Music(
        title: "三日月之舞",
        composer: "堀川奈美惠",
        description: "核心自選曲",
        tag: "Selected"
    ),
    Music(
        title: "普羅旺斯之風",
        composer: "田坂直樹",
        description: "比賽指定曲",
        tag: "Compulsory"
    ),
]

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("首頁", systemImage: "house")
                }

            CharacterListView()
                .tabItem {
                    Label("角色", systemImage: "person.3")
                }

            GalleryView()
                .tabItem {
                    Label("相簿", systemImage: "photo.on.rectangle")
                }

            AboutView()
                .tabItem {
                    Label("關於", systemImage: "info.circle")
                }
        }
        .onAppear {
            let appearance = UITabBarAppearance()
            appearance.configureWithTransparentBackground()
            UITabBar.appearance().scrollEdgeAppearance = appearance
            UITabBar.appearance().standardAppearance = appearance
        }
    }
}
#Preview {
    ContentView()
}
