//
//  timeCalculatorApp.swift
//  timeCalculator
//
//  Created by 陳昰佑 on 2025/12/27.
//

import SwiftUI

@main
struct timeCalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
