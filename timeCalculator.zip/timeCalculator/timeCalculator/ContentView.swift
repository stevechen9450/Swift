import SwiftUI

struct ContentView: View {
    @State private var birthday = Date()

    let animals = [
        ("猴", "🐵"), ("雞", "🐔"), ("狗", "🐶"), ("豬", "🐷"),
        ("鼠", "🐭"), ("牛", "🐮"), ("虎", "🐯"), ("兔", "🐰"),
        ("龍", "🐲"), ("蛇", "🐍"), ("馬", "🐴"), ("羊", "🐏"),
    ]

    var Result: (name: String, icon: String) {
        let year = Calendar.current.component(.year, from: birthday)
        let index = year % 12
        return animals[index]
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("輸入生日") {
                    DatePicker(
                        "你的生日",
                        selection: $birthday,
                        displayedComponents: .date
                    )
                    .datePickerStyle(.graphical)
                }

                Section("生肖") {
                    HStack {
                        Spacer()
                        VStack(spacing: 10) {
                            Text(Result.icon)
                                .font(.system(size: 100))

                            Text("\(Result.name)")
                                .font(.largeTitle)
                                .bold()
                                .foregroundStyle(.black)
                        }
                        Spacer()
                    }
                    .padding(.vertical, 20)
                }
            }
            .navigationTitle("生肖計算機")
        }
    }
}

#Preview {
    ContentView()
}
