//
//  calculatorApp.swift
//  calculator
//
//  Created by 陳昰佑 on 2025/12/28.
//

import SwiftUI

@main
struct calculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
