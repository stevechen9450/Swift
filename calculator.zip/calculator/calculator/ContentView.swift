import SwiftUI

struct ContentView: View {
    @State private var amountInput: String = ""   // 貸款金額
    @State private var rateInput: String = ""     // 年利率 (單位為%)
    @State private var monthsInput: String = ""   // 分期期數 (單位為月)
    
    @FocusState private var isFocused: Bool
    
    var result: (monthPay: Int, totalInterest: Int) {
        let principal = Double(amountInput) ?? 0 // 本金
        let yearRate = Double(rateInput) ?? 0  // 年利率
        let months = Double(monthsInput) ?? 0    // 期數
        
        if principal <= 0 || months <= 0 {
            return (0, 0)
        }
        
        // 情況一：零利率
        if yearRate == 0 {
            let month = principal / months
            return (Int(month), 0)
        }
        
        // 情況二：一般銀行貸款
        // 每月應付 = 本金 * 月利率 * (1+月利率)^期數 / ((1+月利率)^期數 - 1)
        let monthRate = yearRate / 100 / 12 // 月利率
        
        let x = pow(1 + monthRate, months)
        
        let monthPayment = principal * (monthRate * x) / (x - 1)
        let totalPayback = monthPayment * months
        let totalInterest = totalPayback - principal
        
        return (Int(monthPayment), Int(totalInterest))
    }
    
    var body: some View {
        NavigationStack {
            Form {
                Section("貸款資訊") {
                    HStack {
                        Text("貸款金額")
                        Spacer()
                        TextField("例如100000", text: $amountInput)
                            .keyboardType(.numberPad)
                            .focused($isFocused)
                            .multilineTextAlignment(.trailing)
                    }
                    HStack {
                        Text("年利率 (%)")
                        Spacer()
                        TextField("例如2.5", text: $rateInput)
                            .keyboardType(.decimalPad)
                            .focused($isFocused)
                            .multilineTextAlignment(.trailing)
                    }
                    HStack {
                        Text("分期期數 (月)")
                        Spacer()
                        TextField("例如24", text: $monthsInput)
                            .keyboardType(.numberPad)
                            .focused($isFocused)
                            .multilineTextAlignment(.trailing)
                    }
                }
                
                Section("計算結果") {
                    HStack {
                        Text("每期應繳")
                        Spacer()
                        Text("\(result.monthPay)")
                            .font(.title)
                            .bold()
                            .foregroundStyle(.blue)
                    }
                    
                    HStack {
                        Text("總利息")
                        Spacer()
                        Text("\(result.totalInterest)")
                            .foregroundStyle(.black)
                    }
                    
                }
            }
            .navigationTitle("分期付款")
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("完成") {
                        isFocused = false
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
