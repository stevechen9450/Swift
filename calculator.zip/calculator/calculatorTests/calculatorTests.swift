//
//  calculatorTests.swift
//  calculatorTests
//
//  Created by 陳昰佑 on 2025/12/28.
//

import Testing
@testable import calculator

struct calculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
