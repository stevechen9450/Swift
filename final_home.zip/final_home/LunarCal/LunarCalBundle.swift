import SwiftUI
import WidgetKit

@main
struct LunarCalBundle: WidgetBundle {
    var body: some Widget {
        LunarCal()
        LunarCalControl()
        LunarCalLiveActivity()
    }
}
