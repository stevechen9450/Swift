import ActivityKit
import SwiftUI
import WidgetKit

struct LunarCalAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var emoji: String
    }

    var name: String
}

struct LunarCalLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: LunarCalAttributes.self) { context in
            VStack {
                Text("Hello \(context.state.emoji)")
            }
            .activityBackgroundTint(Color.cyan)
            .activitySystemActionForegroundColor(Color.black)

        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Text("Leading")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("Trailing")
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("Bottom \(context.state.emoji)")
                }
            } compactLeading: {
                Text("L")
            } compactTrailing: {
                Text("T \(context.state.emoji)")
            } minimal: {
                Text(context.state.emoji)
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}

extension LunarCalAttributes {
    fileprivate static var preview: LunarCalAttributes {
        LunarCalAttributes(name: "World")
    }
}

extension LunarCalAttributes.ContentState {
    fileprivate static var smiley: LunarCalAttributes.ContentState {
        LunarCalAttributes.ContentState(emoji: "😀")
    }

    fileprivate static var starEyes: LunarCalAttributes.ContentState {
        LunarCalAttributes.ContentState(emoji: "🤩")
    }
}

#Preview("Notification", as: .content, using: LunarCalAttributes.preview) {
    LunarCalLiveActivity()
} contentStates: {
    LunarCalAttributes.ContentState.smiley
    LunarCalAttributes.ContentState.starEyes
}
