import SwiftUI
import WidgetKit

struct SolarTerm {
    let name: String
    let date: Date
}

private func makeDate(year: Int, month: Int, day: Int) -> Date {
    var components = DateComponents()
    components.year = year
    components.month = month
    components.day = day
    components.hour = 0
    components.minute = 0
    components.second = 0
    let calendar = Calendar(identifier: .gregorian)
    return calendar.date(from: components) ?? Date()
}

let solarTerms2026: [SolarTerm] = [
    SolarTerm(name: "小寒", date: makeDate(year: 2026, month: 1, day: 5)),
    SolarTerm(name: "大寒", date: makeDate(year: 2026, month: 1, day: 20)),
    SolarTerm(name: "立春", date: makeDate(year: 2026, month: 2, day: 4)),
    SolarTerm(name: "雨水", date: makeDate(year: 2026, month: 2, day: 19)),
    SolarTerm(name: "驚蟄", date: makeDate(year: 2026, month: 3, day: 5)),
    SolarTerm(name: "春分", date: makeDate(year: 2026, month: 3, day: 20)),
    SolarTerm(name: "清明", date: makeDate(year: 2026, month: 4, day: 4)),
    SolarTerm(name: "穀雨", date: makeDate(year: 2026, month: 4, day: 20)),
    SolarTerm(name: "立夏", date: makeDate(year: 2026, month: 5, day: 5)),
    SolarTerm(name: "小滿", date: makeDate(year: 2026, month: 5, day: 21)),
    SolarTerm(name: "芒種", date: makeDate(year: 2026, month: 6, day: 5)),
    SolarTerm(name: "夏至", date: makeDate(year: 2026, month: 6, day: 21)),
    SolarTerm(name: "小暑", date: makeDate(year: 2026, month: 7, day: 7)),
    SolarTerm(name: "大暑", date: makeDate(year: 2026, month: 7, day: 23)),
    SolarTerm(name: "立秋", date: makeDate(year: 2026, month: 8, day: 7)),
    SolarTerm(name: "處暑", date: makeDate(year: 2026, month: 8, day: 23)),
    SolarTerm(name: "白露", date: makeDate(year: 2026, month: 9, day: 7)),
    SolarTerm(name: "秋分", date: makeDate(year: 2026, month: 9, day: 23)),
    SolarTerm(name: "寒露", date: makeDate(year: 2026, month: 10, day: 8)),
    SolarTerm(name: "霜降", date: makeDate(year: 2026, month: 10, day: 23)),
    SolarTerm(name: "立冬", date: makeDate(year: 2026, month: 11, day: 7)),
    SolarTerm(name: "小雪", date: makeDate(year: 2026, month: 11, day: 22)),
    SolarTerm(name: "大雪", date: makeDate(year: 2026, month: 12, day: 7)),
    SolarTerm(name: "冬至", date: makeDate(year: 2026, month: 12, day: 22)),
]

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        let dummy = SolarTerm(
            name: "立春",
            date: makeDate(year: 2026, month: 2, day: 4)
        )
        return SimpleEntry(date: Date(), solarTerm: dummy, daysRemaining: 10)
    }

    func getSnapshot(
        in context: Context,
        completion: @escaping (SimpleEntry) -> Void
    ) {
        let entry = createEntry(for: Date())
        completion(entry)
    }

    func getTimeline(
        in context: Context,
        completion: @escaping (Timeline<SimpleEntry>) -> Void
    ) {
        var entries: [SimpleEntry] = []
        let currentDate = Date()
        let entry = createEntry(for: currentDate)
        entries.append(entry)

        let calendar = Calendar.current
        let tomorrow =
            calendar.date(
                byAdding: .day,
                value: 1,
                to: calendar.startOfDay(for: currentDate)
            ) ?? currentDate.addingTimeInterval(3600)

        let timeline = Timeline(entries: entries, policy: .after(tomorrow))
        completion(timeline)
    }

    private func createEntry(for date: Date) -> SimpleEntry {
        let calendar = Calendar(identifier: .gregorian)
        let startOfToday = calendar.startOfDay(for: date)

        var targetTerm: SolarTerm?
        var daysLeft: Int = 0

        let sortedTerms = solarTerms2026.sorted { $0.date < $1.date }

        if let termToday = sortedTerms.first(where: {
            calendar.isDate($0.date, inSameDayAs: startOfToday)
        }) {
            targetTerm = termToday
            daysLeft = 0
        } else {
            if let next = sortedTerms.first(where: { $0.date > startOfToday }) {
                targetTerm = next
                let components = calendar.dateComponents(
                    [.day],
                    from: startOfToday,
                    to: next.date
                )
                daysLeft = components.day ?? 0
            } else {
                if let first = sortedTerms.first {
                    targetTerm = first
                    daysLeft = -1
                }
            }
        }

        let safeTerm = targetTerm ?? SolarTerm(name: "Unknown", date: Date())

        return SimpleEntry(
            date: date,
            solarTerm: safeTerm,
            daysRemaining: daysLeft
        )
    }
}

struct SimpleEntry: TimelineEntry {
    let date: Date
    let solarTerm: SolarTerm
    let daysRemaining: Int
}

struct LunarCalEntryView: View {
    var entry: Provider.Entry

    var body: some View {
        VStack(spacing: 4) {
            Text("距離")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.secondary)

            Spacer()

            Text(entry.solarTerm.name)
                .font(.system(size: 34, weight: .bold, design: .serif))
                .foregroundColor(.red)
                .minimumScaleFactor(0.5)
                .multilineTextAlignment(.center)

            Spacer()

            if entry.daysRemaining == 0 {
                Text("Today is \(entry.solarTerm.name)")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
            } else if entry.daysRemaining > 0 {
                Text("還有 \(entry.daysRemaining) 天")
                    .font(.footnote)
                    .fontWeight(.bold)
                    .foregroundColor(.secondary)
            } else {
                Text("2026 End")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .containerBackground(Color(white: 0.95), for: .widget)
    }
}

struct LunarCal: Widget {
    let kind: String = "LunarCal"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            LunarCalEntryView(entry: entry)
        }
        .configurationDisplayName("Solar Term Countdown")
        .description("Countdown to the next Solar Term.")
        .supportedFamilies([.systemSmall])
        .contentMarginsDisabled()
    }
}

#Preview(as: .systemSmall) {
    LunarCal()
} timeline: {
    SimpleEntry(
        date: Date(),
        solarTerm: SolarTerm(name: "立春", date: Date()),
        daysRemaining: 10
    )

    SimpleEntry(
        date: Date(),
        solarTerm: SolarTerm(name: "雨水", date: Date()),
        daysRemaining: 0
    )
}
