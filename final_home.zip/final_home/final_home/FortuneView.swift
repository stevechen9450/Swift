import SwiftUI

// 資料模型
struct FortunePoem: Identifiable {
    let id: Int
    let type: String
    let title: String
    let poem: String
    let explain: String
}

// 籤詩資料庫
class FortuneDatabase {
    static let shared = FortuneDatabase()

    let poems: [FortunePoem] = [
        FortunePoem(
            id: 1,
            type: "上上",
            title: "漢高祖入關",
            poem: "巍巍獨步向雲間，玉殿千官第一班，\n富貴榮華天付汝，福如東海壽如山。",
            explain: "功名大吉，財利亨通。\n【指引】宜多出門走動，納四方之氣，運勢更旺。"
        ),
        FortunePoem(
            id: 2,
            type: "中平",
            title: "韓信謀職",
            poem: "欲去長江水闊茫，前途未遂運未通，\n如今絲綸常在手，只恐魚水不相逢。",
            explain: "時運未至，且宜守舊。\n【指引】與其在家煩惱，不如外出健走，轉換心情可轉運。"
        ),
        FortunePoem(
            id: 3,
            type: "下下",
            title: "項羽被困",
            poem: "風搖燈燭燄時滅，暗室推門卻閉開，\n去去重重無進退，受恩深處便生災。",
            explain: "運勢閉塞，凡事謹慎。\n【指引】切勿鬱悶在家，應多至戶外公園散心，方能解憂。"
        ),
        FortunePoem(
            id: 4,
            type: "上吉",
            title: "姜太公釣魚",
            poem: "君今庚甲未亨通，且向江頭作釣翁，\n玉兔重生應發跡，萬人頭上逞英雄。",
            explain: "先難後易，苦盡甘來。\n【指引】出外將遇貴人提拔，多去戶外活動有益健康與運勢。"
        ),
    ]

    func getRandomPoem() -> FortunePoem {
        poems.randomElement() ?? poems[0]
    }
}

// 靈籤擲筊
struct FortuneView: View {
    enum GameState {
        case start          // Initial state: Instructions
        case praying        // Step 1: Praying (User waits 10 mins notionally)
        case askingPermission // Step 2: Ask if can draw
        case castingPermission // Animation for Step 2
        case drawingLot     // Step 3: Draw a stick
        case confirmingLot  // Step 4: Ask if this stick is correct
        case castingConfirm // Animation for Step 4
        case result         // Show Poem
    }

    enum MoonBlockResult {
        case holy, laughing, yin
        var title: String {
            switch self {
            case .holy: return "聖筊 (吉)"
            case .laughing: return "笑筊 (不准)"
            case .yin: return "陰筊 (不准)"
            }
        }
        var color: Color {
            switch self {
            case .holy: return .red800
            case .laughing: return .green
            case .yin: return .blue
            }
        }
    }

    @State private var gameState: GameState = .start
    @State private var currentLotNumber: Int = 0
    @State private var moonBlockResult: MoonBlockResult? = nil
    @State private var blockRotation = 0.0
    @State private var resultPoem: FortunePoem?
    @State private var showPoemSheet = false
    
    @State private var consecutiveHolyCount = 0
    @State private var statusMessage: String = ""
    @State private var showToast = false
// funcs

    func startPraying() {
        withAnimation {
            gameState = .praying
            statusMessage = "請點香參拜，稟報姓名、生辰、地址及所求之事。\n(待10分鐘後擲筊)"
        }
    }

    func finishPraying() {
        withAnimation {
            gameState = .askingPermission
            statusMessage = "請問神明，現在是否可以抽籤？\n(需聖筊允准)"
            moonBlockResult = nil
        }
    }

    func castForPermission() {
        gameState = .castingPermission
        SoundManager.shared.playWoodBlockSound()
        animateBlocks()

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            let result = rollBlocks()
            moonBlockResult = result
            
            if result == .holy {
                // 成功
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    gameState = .drawingLot
                    statusMessage = "獲神明允准。\n請從籤筒中抽出的一支籤。"
                    moonBlockResult = nil
                }
            } else {
                // 重來
                statusMessage = result == .laughing ? "笑筊：問題不清楚，請重新稟報。" : "陰筊：神明不允，請稍後再試。"
                gameState = .askingPermission
            }
        }
    }

    func drawLot() {
        gameState = .drawingLot
        currentLotNumber = Int.random(in: 1...60)
        
        withAnimation {
            gameState = .confirmingLot
            consecutiveHolyCount = 0
            statusMessage = "抽出第 \(currentLotNumber) 籤。\n請問神明是不是這支籤？\n(需連續 3 聖筊)"
            moonBlockResult = nil
        }
    }

    func castForConfirmation() {
        gameState = .castingConfirm
        SoundManager.shared.playWoodBlockSound()
        animateBlocks()

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            let result = rollBlocks()
            moonBlockResult = result
            
            if result == .holy {
                consecutiveHolyCount += 1
                if consecutiveHolyCount >= 3 {
                    // 成功
                    resultPoem = FortuneDatabase.shared.getRandomPoem()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        gameState = .result
                        showPoemSheet = true
                    }
                } else {
                    statusMessage = "聖筊 (\(consecutiveHolyCount)/3)。\n請繼續擲筊確認。"
                    gameState = .confirmingLot
                }
            } else {
                // 失敗
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    statusMessage = "不是這支籤 (中斷)。\n請重抽。"
                    gameState = .drawingLot
                    currentLotNumber = 0
                    consecutiveHolyCount = 0
                    moonBlockResult = nil
                }
            }
        }
    }

    func reset() {
        withAnimation {
            gameState = .start
            moonBlockResult = nil
            currentLotNumber = 0
            consecutiveHolyCount = 0
            blockRotation = 0
            statusMessage = ""
        }
    }

    func rollBlocks() -> MoonBlockResult {
        let roll = Int.random(in: 1...100)
        if roll <= 45 { return .holy }      // 45%
        else if roll <= 80 { return .laughing } // 35%
        else { return .yin }             // 20%
    }

    func animateBlocks() {
        withAnimation(.spring(response: 0.5, dampingFraction: 0.5)) {
            blockRotation += 360
        }
    }


    var body: some View {
        ZStack {
            LinearGradient(colors: [.stone50, .stone100], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("誠心求靈籤")
                    .font(.system(.largeTitle, design: .serif))
                    .fontWeight(.bold)
                    .foregroundColor(.red800)
                    .padding(.top, 40)

                if !statusMessage.isEmpty {
                    Text(statusMessage)
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.gray)
                        .padding(.horizontal)
                        .transition(.opacity)
                }

                Spacer()

                
                
                
                ZStack {
                    if gameState == .start {
                        VStack(spacing: 20) {
                            Image(systemName: "flame.fill")
                                .font(.system(size: 80))
                                .foregroundColor(.orange)
                            Text("準備好開始了嗎？")
                                .foregroundColor(.secondary)
                        }
                    }
                    else if gameState == .praying {
                        VStack(spacing: 20) {
                            Image(systemName: "hands.sparkles.fill")
                                .font(.system(size: 100))
                                .foregroundColor(.amber600)
                                .opacity(0.8)
                            Text("稟報中...")
                                .font(.headline)
                        }
                    }
                    else if gameState == .drawingLot {
                        VStack {
                            Image(systemName: "cylinder.split.1x2.fill")
                                .font(.system(size: 100))
                                .foregroundColor(.amber600)
                            Text("搖籤中...")
                        }
                    }
                    else {
                        VStack(spacing: 30) {
                            if currentLotNumber > 0 {
                                Text("第 \(currentLotNumber) 籤")
                                    .font(.system(size: 40, weight: .bold))
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(8)
                                    .shadow(radius: 5)
                            }
                            
                            HStack(spacing: 40) {
                                moonBlockView(isLeft: true)
                                moonBlockView(isLeft: false)
                            }
                            
                            if let result = moonBlockResult {
                                Text(result.title)
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(result == .holy ? .green : .red)
                                    .transition(.scale)
                            }
                        }
                    }
                }

                Spacer()


                
                VStack {
                    if gameState == .start {
                        Button(action: startPraying) {
                            ActionButton(text: "點香參拜", color: .red800)
                        }
                    } else if gameState == .praying {
                        Button(action: finishPraying) {
                            ActionButton(text: "稟報完畢，擲筊問准", color: .amber600)
                        }
                    } else if gameState == .askingPermission {
                        Button(action: castForPermission) {
                            ActionButton(text: "擲筊 (問能否抽籤)", color: .red800)
                        }
                    } else if gameState == .drawingLot {
                        Button(action: drawLot) {
                            ActionButton(text: "抽籤", color: .amber600)
                        }
                    } else if gameState == .confirmingLot {
                        Button(action: castForConfirmation) {
                            ActionButton(text: "擲筊確認 (需3聖筊)", color: .red800)
                        }
                    } else if gameState == .result {
                         Button(action: { showPoemSheet = true }) {
                            ActionButton(text: "查看籤詩", color: .red800)
                        }
                    }
                    
                    if gameState != .start {
                         Button(action: reset) {
                            Text("重置")
                                .foregroundColor(.gray)
                                .padding(.top, 10)
                        }
                    }
                }
                .padding(.horizontal, 40)
                .padding(.bottom, 30)
            }
        }
        .sheet(isPresented: $showPoemSheet, onDismiss: { reset() }) {
            if let poem = resultPoem {
                FortuneResultView(poem: poem)
            }
        }
    }


    func moonBlockView(isLeft: Bool) -> some View {
        var isFlatUp = true
        
        if let result = moonBlockResult {
             switch result {
             case .holy:
                 isFlatUp = isLeft ? true : false
             case .laughing:
                 isFlatUp = true
             case .yin:
                 isFlatUp = false
             }
        } else {
            isFlatUp = true
        }
        
        return ZStack {
             Circle()
                 .trim(from: 0, to: 0.5)
                 .frame(width: 80, height: 80)
                 .foregroundColor(.red700)
                 .rotationEffect(.degrees(isFlatUp ? 0 : 180))
                 .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 5)
             
             if !isFlatUp {
                 Circle()
                     .trim(from: 0, to: 0.5)
                     .frame(width: 80, height: 80)
                     .foregroundColor(.black.opacity(0.2))
                     .rotationEffect(.degrees(180))
             }
         }
         .rotationEffect(.degrees(blockRotation))
    }
}



struct ActionButton: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text)
            .fontWeight(.bold)
            .frame(maxWidth: .infinity)
            .padding()
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(15)
    }
}

struct FortuneResultView: View {
    @Environment(\.dismiss) var dismiss
    let poem: FortunePoem
    var body: some View {
        ZStack {
            Color.stone50.ignoresSafeArea()
            RoundedRectangle(cornerRadius: 20).stroke(
                Color.red800,
                lineWidth: 5
            ).padding(15)
            ScrollView {
                VStack(spacing: 25) {
                    VStack(spacing: 10) {
                        Text("第 \(poem.id) 籤").font(.headline).foregroundColor(
                            .gray
                        )
                        Text(poem.type).font(
                            .system(size: 60, weight: .heavy, design: .serif)
                        ).foregroundColor(.red800)
                        Text(poem.title).font(.title).fontWeight(.bold)
                    }.padding(.top, 40)
                    Divider().background(Color.red800).padding(.horizontal, 40)

                    Text(poem.poem)
                        .font(.title2)
                        .fontWeight(.medium)
                        .lineSpacing(10)
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 20)
                        .frame(maxWidth: .infinity)
                        .background(Color.stone100)
                        .cornerRadius(10)
                        .padding(.horizontal)

                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "text.book.closed.fill")
                                .foregroundColor(.amber600)
                            Text("聖意解析").font(.headline).foregroundColor(
                                .amber600
                            )
                        }
                        Text(poem.explain)
                            .font(.body)
                            .foregroundColor(.primary)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: .black.opacity(0.05), radius: 3)
                    }.padding(.horizontal)

                    Spacer(minLength: 50)
                    Button("叩謝神恩") { dismiss() }.font(.headline).padding()
                        .frame(maxWidth: .infinity).background(Color.red800)
                        .foregroundColor(.white).cornerRadius(12).padding(
                            .horizontal
                        ).padding(.bottom, 20)
                }
            }
        }
    }
}
