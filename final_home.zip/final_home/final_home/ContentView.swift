import AVFoundation
import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {

            TaiSuiView()
                .tabItem {
                    Label(
                        "太歲查詢",
                        systemImage: "person.crop.circle.badge.questionmark"
                    )
                }

            FarmerCalendarView()
                .tabItem {
                    Label("農民曆", systemImage: "calendar")
                }

            FortuneView()
                .tabItem {
                    Label("靈籤擲筊", systemImage: "sparkles.rectangle.stack")
                }
        }
        .accentColor(.red800)
    }
}

//音效管理器
class SoundManager {
    static let shared = SoundManager()

    func playBlessingSoundOnce() {
        AudioServicesPlaySystemSound(1004)
    }

    func playWoodBlockSound() {
        AudioServicesPlaySystemSound(1105)
    }
}

// 顏色
extension Color {
    static let red700 = Color(red: 0.75, green: 0.11, blue: 0.11)
    static let red800 = Color(red: 0.65, green: 0.08, blue: 0.08)
    static let amber600 = Color(red: 0.85, green: 0.55, blue: 0.02)
    static let amber500 = Color(red: 0.95, green: 0.65, blue: 0.12)
    static let stone50 = Color(red: 0.98, green: 0.98, blue: 0.97)
    static let stone100 = Color(red: 0.96, green: 0.96, blue: 0.95)
}

//資料結構
struct TaiSuiInfo {
    let zodiac: String
    let conflictType: String
    let age: Int?
    let description: String
    let suggestion: String
}

enum ServiceType: String, Codable {
    case lightLamp = "光明燈"
    case anTaiSui = "安太歲"
}

struct ServiceHistory: Identifiable, Codable {
    var id = UUID()
    let type: ServiceType
    let personName: String
    let date: Date
    let year: Int
}

// 練習製作一天的日曆，不會顯示在本App裡面

struct OldCalendarView: View {
    let blueColor = Color(red: 0, green: 0, blue: 0.9)

    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all)

            VStack(alignment: .leading, spacing: 10) {
                Text("農大")
                    .font(.system(size: 20, weight: .bold))
                    .overlay(
                        Rectangle().frame(height: 2).offset(y: 22),
                        alignment: .bottom
                    )

                Text("五\n月\n廿\n六\n日")
                    .font(.system(size: 45, weight: .bold))
                    .lineSpacing(10)
            }
            .foregroundColor(blueColor)
            .offset(x: -160, y: -200)

            HStack(spacing: 30) {
                Text("2025")
                    .font(.system(size: 35, weight: .bold, design: .serif))
                    .italic()
                Text("歲次乙巳年")
                    .font(.system(size: 24, weight: .medium))
            }
            .foregroundColor(blueColor)
            .offset(y: -350)

            VStack(alignment: .trailing) {
                HStack(alignment: .lastTextBaseline) {
                    Text("6")
                        .font(.system(size: 100, weight: .bold, design: .serif))
                    VStack(alignment: .leading) {
                        Text("JUN")
                        Text("月")
                    }
                    .font(.system(size: 20, weight: .bold))
                }

                Text("S M T W T F S\n 3 4 5 6 7 8 ...")
                    .font(.system(size: 12, design: .monospaced))
                    .multilineTextAlignment(.trailing)
            }
            .foregroundColor(blueColor)
            .offset(x: 130, y: -280)

            Text("22")
                .font(.system(size: 230, weight: .black, design: .serif))
                .foregroundColor(blueColor)
                .offset(y: -50)

            VStack(spacing: 5) {
                Text("星 期 五")
                    .font(.system(size: 60, weight: .bold))
                Text("FRIDAY")
                    .font(.system(size: 30, weight: .black))
                    .kerning(10)  // 字距
            }
            .foregroundColor(blueColor)
            .offset(y: 200)

            VStack(alignment: .leading, spacing: 5) {

            }
            .foregroundColor(blueColor)
            .offset(x: 120, y: 50)

            HStack {

                Text("宜 / 不宜").padding().border(blueColor, width: 2)
                Spacer()
                Text("節氣 / 胎神").padding().border(blueColor, width: 2)
            }
            .padding(.horizontal)
            .foregroundColor(blueColor)
            .offset(y: 350)
        }
    }
}
#Preview {
    //OldCalendarView()
    ContentView()
}
