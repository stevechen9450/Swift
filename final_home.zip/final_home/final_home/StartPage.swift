import SwiftUI

// 狀態列舉
enum StartPageStatus {
    case selectYear
    case mainApp(year: Int)
    case developing(year: Int)
}

// App 程式的入口
@main
struct final_homeApp: App {
    @State private var page: StartPageStatus = .selectYear
    @State private var selectedYear: Int = 2026

    var body: some Scene {
        WindowGroup {
            switch page {
            case .selectYear:
                YearSelectionView(selectedYear: $selectedYear) { year in
                    if year == 2026 {
                        page = .mainApp(year: year)
                    } else {
                        page = .developing(year: year)
                    }
                }
            case .mainApp(let year):
                ContentView()
                    .transition(.slide)
            case .developing(let year):
                DevelopingView(year: year) {
                    page = .selectYear
                }
            }
        }
    }
}

// 年份選擇畫面
struct YearSelectionView: View {
    @Binding var selectedYear: Int
    var onYearSelected: (Int) -> Void
    let years = [2026, 2027, 2028]

    var body: some View {
        VStack(spacing: 40) {
            Text("請選擇查詢年份")
                .font(.title)
                .fontWeight(.bold)
                .padding(.top, 100)

            Picker("選擇年份", selection: $selectedYear) {
                ForEach(years, id: \.self) { year in
                    Text("\(year)").tag(year)
                }
            }
            #if os(iOS)
                .pickerStyle(.wheel)
                .frame(height: 130)
            #else
                .pickerStyle(.segmented)
            #endif
            .labelsHidden()

            Button {
                onYearSelected(selectedYear)
            } label: {
                Text("確認")
                    .font(.title2)
                    .frame(minWidth: 120)
                    .padding()
                    .background(Color.red.opacity(0.85))
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            Spacer()
        }
        .background(
            LinearGradient(
                colors: [.stone50, .stone100],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
    }
}

// 開發中畫面
struct DevelopingView: View {
    let year: Int
    var onBack: () -> Void

    var body: some View {
        VStack(spacing: 30) {
            Spacer()
            Text("🙂‍↔️ \(year) 年功能開發中")
                .font(.largeTitle)
                .fontWeight(.bold)
            Text("請回到首頁選擇 2026 年體驗完整服務")
                .foregroundColor(.secondary)
            Button("返回") {
                onBack()
            }
            .font(.title2)
            .padding()
            .background(Color.red.opacity(0.85))
            .foregroundColor(.white)
            .cornerRadius(12)
            Spacer()
        }
    }
}
