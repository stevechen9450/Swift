import SwiftUI

//struct AlmanacDay
struct AlmanacDay: Identifiable, Hashable {
    let id = UUID()
    let yearStr: String  // 2026 丙午年
    let monthEn: String  // 月
    let monthNum: String  // 月的數字
    let dayNum: String  // 日
    let weekDay: String  // 星期幾
    let weekDayEn: String  // 星期幾的英文
    let lunarDate: String  // 農曆
    let yi: [String]  // 宜
    let ji: [String]  // 忌
    let solarTerm: String?  // 有沒有二十四節氣
    var isHoliday: Bool  // 是不是假日
}

// 路徑
enum CalendarRoute: Hashable {
    case today
    case monthDashboard(Int)  // 進入某個月份
    case dayDetail(month: Int, dayIndex: Int)  // 進入撕日曆模式
}


struct FarmerCalendarView: View {
    @State private var path = NavigationPath()
    @State private var hasJumpedToToday = false

    var body: some View {
        NavigationStack(path: $path) {
            FarmerCalendarMenuView()
                .navigationTitle("農民曆選單")
                .navigationDestination(for: CalendarRoute.self) { route in
                    switch route {
                    case .today:
                        TodayView()
                    case .monthDashboard(let month):
                        if month <= 2 {
                            MonthDashboardView(month: month)
                        } else {
                            UnderConstructionView(month: month)
                        }
                    case .dayDetail(let month, let dayIndex):
                        MonthDetailView(month: month, initialIndex: dayIndex)
                    }
                }
        }
        .onAppear {
            if !hasJumpedToToday {
                hasJumpedToToday = true
                path.append(CalendarRoute.today)
            }
        }
    }
}

// 選單頁面
struct FarmerCalendarMenuView: View {
    let months = Array(1...12)

    func getMonthEnName(_ month: Int) -> String {
        let names = [
            "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEPT",
            "OCT", "NOV", "DEC",
        ]
        return names[month - 1]
    }

    var body: some View {
        List {
            Section("快速前往") {
                NavigationLink(value: CalendarRoute.today) {
                    HStack {
                        Image(systemName: "sun.max.fill").foregroundColor(
                            .orange
                        )
                        Text("查看今日運勢").fontWeight(.bold)
                        Spacer()
                        Text(Date().formatted(date: .numeric, time: .omitted))
                            .font(.caption).foregroundColor(.gray)
                    }
                    .padding(.vertical, 8)
                }
            }

            Section("月份瀏覽 (2026 丙午年)") {
                ForEach(months, id: \.self) { month in
                    NavigationLink(value: CalendarRoute.monthDashboard(month)) {
                        HStack {
                            Text("\(month) 月")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(month <= 2 ? .primary : .gray)
                            Spacer()
                            Text(getMonthEnName(month))
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(5)
                        }
                        .padding(.vertical, 5)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
    }
}

// 今日頁面
struct TodayView: View {
    let today = Date()

    var body: some View {
        ZStack {
            Color(white: 0.95).ignoresSafeArea()
            VStack(spacing: 20) {
                VStack(spacing: 0) {
                    HStack {
                        Text(today.formatted(.dateTime.year()))
                        Spacer()
                        Text(today.formatted(.dateTime.weekday(.wide)))
                    }
                    .padding()
                    .background(Color.red700)
                    .foregroundColor(.white)
                    .font(.headline)

                    VStack {
                        Text(today.formatted(.dateTime.day()))
                            .font(
                                .system(
                                    size: 120,
                                    weight: .black,
                                    design: .serif
                                )
                            )
                            .foregroundColor(.black)
                        Text(today.formatted(.dateTime.month(.wide)))
                            .font(.title2)
                            .foregroundColor(.gray)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
                    .background(Color.white)

                    VStack(spacing: 10) {
                        Image(systemName: "archivebox.fill").font(.largeTitle)
                            .foregroundColor(.gray)
                        Text("暫無今日詳細資料").font(.headline).foregroundColor(
                            .primary
                        )
                    }
                    .frame(maxWidth: .infinity)
                    .padding(30)
                    .background(Color.stone50)
                }
                .cornerRadius(16)
                .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 5)
                .padding(30)
                Spacer()
            }
        }
        .navigationTitle("今日運勢")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// 月份頁面
struct MonthDashboardView: View {
    let month: Int
    let days: [AlmanacDay]

    @State private var selectedYi: String = "無篩選"
    @State private var selectedJi: String = "無篩選"

    let columns = Array(repeating: GridItem(.flexible(), spacing: 0), count: 7)
    let weekHeaders = ["日", "一", "二", "三", "四", "五", "六"]

    var startOffset: Int {
        if month == 1 { return 4 }  // 1/1 是星期四
        if month == 2 { return 0 }  // 2/1 是星期日
        return 0
    }

    var allYiOptions: [String] {
        let all = days.flatMap { $0.yi }
        return ["無篩選"] + Array(Set(all)).sorted()
    }

    var allJiOptions: [String] {
        let all = days.flatMap { $0.ji }
        return ["無篩選"] + Array(Set(all)).sorted()
    }

    init(month: Int) {
        self.month = month
        if month == 1 {
            self.days = CalendarDatabase.januaryDays
        } else {
            self.days = CalendarDatabase.februaryDays
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            filterSection
            weekHeaderSection
            calendarGrid
        }
        .background(Color.white)
        .navigationTitle("\(month)月")
        .navigationBarTitleDisplayMode(.inline)
    }

    // 篩選
    private var filterSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 15) {
                // 宜
                VStack(alignment: .leading, spacing: 2) {
                    Text("宜").font(.caption).bold()
                    Menu {
                        Picker("選擇動作", selection: $selectedYi) {
                            ForEach(allYiOptions, id: \.self) { option in
                                Text(option).tag(option)
                            }
                        }
                    } label: {
                        HStack {
                            Text(selectedYi)
                                .foregroundColor(
                                    selectedYi == "無篩選" ? .gray : .primary
                                )
                                .lineLimit(1)
                            Spacer()
                            Image(systemName: "chevron.down").font(.caption)
                                .foregroundColor(.gray)
                        }
                        .padding(8)
                        .background(Color.white)
                        .cornerRadius(5)
                        .overlay(
                            RoundedRectangle(cornerRadius: 5).stroke(
                                Color.gray.opacity(0.3)
                            )
                        )
                    }
                }

                // 忌
                VStack(alignment: .leading, spacing: 2) {
                    Text("忌").font(.caption).bold().foregroundColor(.red)
                    Menu {
                        Picker("選擇動作", selection: $selectedJi) {
                            ForEach(allJiOptions, id: \.self) { option in
                                Text(option).tag(option)
                            }
                        }
                    } label: {
                        HStack {
                            Text(selectedJi)
                                .foregroundColor(
                                    selectedJi == "無篩選" ? .gray : .primary
                                )
                                .lineLimit(1)
                            Spacer()
                            Image(systemName: "chevron.down").font(.caption)
                                .foregroundColor(.gray)
                        }
                        .padding(8)
                        .background(Color.white)
                        .cornerRadius(5)
                        .overlay(
                            RoundedRectangle(cornerRadius: 5).stroke(
                                Color.gray.opacity(0.3)
                            )
                        )
                    }
                }
            }
        }
        .padding()
        .background(Color.stone50)
    }

    // 星期幾標題
    private var weekHeaderSection: some View {
        LazyVGrid(columns: columns, spacing: 0) {
            ForEach(weekHeaders, id: \.self) { day in
                Text(day)
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .frame(height: 40)
                    .frame(maxWidth: .infinity)
                    .border(Color.black, width: 0.5)
            }
        }
        .background(Color.white)
    }

    // 日曆捲動
    private var calendarGrid: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 0) {
                // 填補空格
                ForEach(0..<startOffset, id: \.self) { _ in
                    Color.clear
                        .frame(height: 80)
                        .border(Color.black, width: 0.5)
                }

                // 日期資料
                ForEach(Array(days.enumerated()), id: \.element.id) {
                    index,
                    day in
                    dayCell(index: index, day: day)
                }
            }
            .padding(.bottom, 20)
        }
    }

    private func dayCell(index: Int, day: AlmanacDay) -> some View {
        // 篩選邏輯
        let isYiMatch = selectedYi == "無篩選" || day.yi.contains(selectedYi)
        let isJiMatch = selectedJi == "無篩選" || day.ji.contains(selectedJi)
        let isMatch = isYiMatch && isJiMatch

        let lunarText: String = day.solarTerm ?? String(day.lunarDate.suffix(2))

        return NavigationLink(
            value: CalendarRoute.dayDetail(month: month, dayIndex: index)
        ) {
            VStack(spacing: 4) {
                // 國曆
                Text(day.dayNum)
                    .font(.system(size: 20, weight: .regular))
                    .foregroundColor(.black)

                // 農曆/節氣
                Text(lunarText)
                    .font(.system(size: 12))
                    .foregroundColor(.black)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 80)
            .background(
                day.isHoliday
                    ? Color(red: 1.0, green: 0.6, blue: 0.9) : Color.white
            )
            .opacity(isMatch ? 1.0 : 0.1)
            .border(Color.black, width: 0.5)
        }
        .disabled(!isMatch)
    }
}

// 撕日曆
struct MonthDetailView: View {
    let month: Int
    let days: [AlmanacDay]
    let initialIndex: Int

    @State private var currentIndex: Int
    @State private var dragOffset: CGSize = .zero
    @State private var dragRotation: Double = 0

    init(month: Int, initialIndex: Int) {
        self.month = month
        self.initialIndex = initialIndex

        if month == 1 {
            self.days = CalendarDatabase.januaryDays
        } else {
            self.days = CalendarDatabase.februaryDays
        }
        _currentIndex = State(initialValue: initialIndex)
    }

    var body: some View {
        ZStack {
            Color(white: 0.95).ignoresSafeArea()

            if currentIndex < days.count {
                ZStack {
                    if currentIndex + 1 < days.count {
                        DailyCalendarPage(day: days[currentIndex + 1])
                            .padding(.horizontal, 25)
                            .scaleEffect(0.95)
                            .opacity(0.8)
                            .offset(y: -10)
                    }

                    DailyCalendarPage(day: days[currentIndex])
                        .padding(.horizontal, 25)
                        .rotation3DEffect(
                            .degrees(dragRotation),
                            axis: (x: 1.0, y: 0.0, z: 0.0),
                            anchor: .top,
                            anchorZ: 0.0,
                            perspective: 0.5
                        )
                        .offset(y: dragOffset.height)
                        .opacity(200.0 / (200.0 + Double(dragOffset.height)))
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    if value.translation.height > 0 {
                                        self.dragOffset = value.translation
                                        let progress = min(
                                            value.translation.height / 500,
                                            1.0
                                        )
                                        self.dragRotation = -progress * 45
                                    }
                                }
                                .onEnded { value in
                                    if value.translation.height > 150 {
                                        withAnimation(.easeIn(duration: 0.3)) {
                                            self.dragOffset.height = 1000
                                            self.dragRotation = -90
                                        }
                                        #if os(iOS)
                                            let generator =
                                                UIImpactFeedbackGenerator(
                                                    style: .heavy
                                                )
                                            generator.impactOccurred()
                                        #endif
                                        DispatchQueue.main.asyncAfter(
                                            deadline: .now() + 0.3
                                        ) {
                                            self.currentIndex += 1
                                            self.dragOffset = .zero
                                            self.dragRotation = 0
                                        }
                                    } else {
                                        withAnimation(
                                            .spring(
                                                response: 0.4,
                                                dampingFraction: 0.6
                                            )
                                        ) {
                                            self.dragOffset = .zero
                                            self.dragRotation = 0
                                        }
                                    }
                                }
                        )
                }
            } else {
                VStack(spacing: 20) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 80))
                        .foregroundColor(.green)
                    Text("本月已結束")
                        .font(.title)
                        .foregroundColor(.gray)
                    Button("回到第一天") {
                        withAnimation { currentIndex = 0 }
                    }
                }
            }
        }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// 製作中頁面
struct UnderConstructionView: View {
    let month: Int
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "hammer.fill").font(.system(size: 80))
                .foregroundColor(.gray)
            Text("\(month) 月資料製作中").font(.title).fontWeight(.bold)
                .foregroundColor(.gray)
            Text("請稍後再回來查看").foregroundColor(.secondary)
        }
        .padding()
        .background(Color(white: 0.95))
    }
}

// 單日日曆頁面
struct DailyCalendarPage: View {
    let day: AlmanacDay
    private var mainColor: Color {
        day.isHoliday ? Color.red700 : Color(red: 0.1, green: 0.1, blue: 0.4)
    }

    var body: some View {
        GeometryReader { geo in
            VStack(spacing: 0) {
                Image("bt_7_301_01_P1_11_e2")
                    .resizable()
                    .scaledToFill()
                    .frame(width: geo.size.width, height: 80)
                    .clipped()

                HStack(spacing: 12) {
                    ForEach(0..<10) { _ in
                        Circle().fill(Color(white: 0.9)).frame(
                            width: 15,
                            height: 15
                        )
                        .overlay(
                            Circle().stroke(
                                Color.black.opacity(0.2),
                                lineWidth: 2
                            ).blur(radius: 1).offset(x: 1, y: 1).mask(Circle())
                        )
                    }
                }.padding(.top, 10).frame(maxWidth: .infinity).background(
                    Color(white: 0.92)
                )

                VStack(spacing: 0) {
                    VStack(spacing: 8) {
                        Text(day.yearStr).font(
                            .system(size: 16, weight: .medium, design: .serif)
                        ).tracking(4).foregroundColor(.gray)
                        Divider().background(Color.gray.opacity(0.3))
                    }.padding(.top, 20).padding(.horizontal, 20)

                    ZStack {
                        VStack(spacing: 4) {
                            ForEach(Array(day.lunarDate), id: \.self) { char in
                                Text(String(char)).font(
                                    .system(
                                        size: 28,
                                        weight: .bold,
                                        design: .serif
                                    )
                                )
                            }
                        }.foregroundColor(mainColor).position(
                            x: geo.size.width * 0.15,
                            y: geo.size.height * 0.18
                        )

                        Text(day.dayNum).font(
                            .system(size: 160, weight: .black, design: .serif)
                        ).foregroundColor(mainColor).offset(y: -40)

                        VStack(spacing: 0) {
                            Text(day.monthNum).font(
                                .system(size: 50, weight: .bold)
                            )
                            Text("月").font(.title3)
                            Text(day.monthEn).font(
                                .system(size: 12, weight: .bold)
                            ).tracking(1).padding(.top, 2)
                        }.foregroundColor(mainColor).position(
                            x: geo.size.width * 0.82,
                            y: geo.size.height * 0.12
                        )
                    }.frame(height: geo.size.height * 0.45)

                    VStack(spacing: 5) {
                        Text(day.weekDay).font(
                            .system(size: 55, weight: .black, design: .serif)
                        )
                        Text(day.weekDayEn).font(
                            .system(size: 16, weight: .bold)
                        ).tracking(6).opacity(0.7)
                    }.foregroundColor(mainColor).offset(y: -50)

                    HStack(spacing: 0) {
                        TraditionalYiJiBox(
                            title: "宜",
                            items: day.yi,
                            color: .black
                        )
                        TraditionalYiJiBox(
                            title: "忌",
                            items: day.ji,
                            color: .red
                        )
                    }.padding(.horizontal, 20).padding(.bottom, 20).offset(
                        y: -20
                    )

                    if let term = day.solarTerm {
                        HStack {
                            Spacer()
                            Text(term).font(
                                .system(
                                    size: 24,
                                    weight: .heavy,
                                    design: .serif
                                )
                            ).padding(.horizontal, 12).padding(.vertical, 8)
                                .foregroundColor(.red)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4).stroke(
                                        Color.red,
                                        lineWidth: 3
                                    )
                                )
                                .background(Color.white.opacity(0.8))
                                .rotationEffect(.degrees(-15))
                                .padding(.trailing, 30).padding(.bottom, 30)
                        }
                    } else {
                        Spacer().frame(height: 60)
                    }
                }
            }
            .background(Color.white).cornerRadius(2).shadow(
                color: Color.black.opacity(0.15),
                radius: 15,
                x: 0,
                y: 10
            )
            .frame(height: geo.size.height * 0.88).position(
                x: geo.size.width / 2,
                y: geo.size.height / 2
            )
        }
    }
}

struct TraditionalYiJiBox: View {
    let title: String
    let items: [String]
    let color: Color
    var body: some View {
        VStack(spacing: 0) {
            Text(title).font(.system(size: 20, weight: .bold)).foregroundColor(
                .white
            ).frame(maxWidth: .infinity).padding(.vertical, 6).background(color)
            VStack(spacing: 8) {
                let displayItems = Array(items.prefix(6))
                ForEach(0..<(displayItems.count + 1) / 2, id: \.self) { index in
                    HStack {
                        Text(displayItems[index * 2])
                        if index * 2 + 1 < displayItems.count {
                            Text(displayItems[index * 2 + 1])
                        }
                    }.font(.system(size: 16, weight: .medium, design: .serif))
                        .foregroundColor(.black)
                }
            }.padding(.vertical, 12).frame(
                maxWidth: .infinity,
                minHeight: 80,
                alignment: .top
            ).border(color, width: 2)
        }
    }
}

// 資料庫 (2026 1月 & 2月)
class CalendarDatabase {

    // 2026年 1月
    static let januaryDays: [AlmanacDay] = [
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "1",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "十一月十三",
            yi: ["祭祀", "祈福", "開光", "出行"],
            ji: ["動土", "破土", "安葬"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "2",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "十一月十四",
            yi: ["交易", "立券", "納財"],
            ji: ["嫁娶", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "3",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "十一月十五",
            yi: ["修造", "動土", "安床"],
            ji: ["出行", "栽種"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "4",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "十一月十六",
            yi: ["祭祀", "作灶", "解除"],
            ji: ["開市", "安葬"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "5",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "十一月十七",
            yi: ["沐浴", "掃舍", "餘事勿取"],
            ji: ["諸事不宜"],
            solarTerm: "小寒",
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "6",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "十一月十八",
            yi: ["嫁娶", "訂盟", "納采"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "7",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "十一月十九",
            yi: ["祭祀", "祈福", "求嗣"],
            ji: ["動土", "破土"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "8",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "十一月二十",
            yi: ["開市", "交易", "立券"],
            ji: ["嫁娶", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "9",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "十一月廿一",
            yi: ["入宅", "移徙", "安床"],
            ji: ["作灶", "祭祀"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "10",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "十一月廿二",
            yi: ["祭祀", "解除", "破屋"],
            ji: ["餘事勿取"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "11",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "十一月廿三",
            yi: ["祭祀", "祈福", "出行"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "12",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "十一月廿四",
            yi: ["修造", "動土", "上樑"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "13",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "十一月廿五",
            yi: ["嫁娶", "納采", "訂盟"],
            ji: ["開市", "安床"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "14",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "十一月廿六",
            yi: ["開市", "交易", "立券"],
            ji: ["出行", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "15",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "十一月廿七",
            yi: ["入宅", "安香", "安床"],
            ji: ["修造", "動土"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "16",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "十一月廿八",
            yi: ["祭祀", "祈福", "齋醮"],
            ji: ["嫁娶", "開市"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "17",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "十一月廿九",
            yi: ["理髮", "沐浴", "作灶"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "18",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "十一月三十",
            yi: ["嫁娶", "訂盟", "納采"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "19",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "臘月初一",
            yi: ["祭祀", "祈福", "求嗣"],
            ji: ["動土", "破土"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "20",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "臘月初二",
            yi: ["解除", "掃舍", "壞垣"],
            ji: ["餘事勿取"],
            solarTerm: "大寒",
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "21",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "臘月初三",
            yi: ["開市", "交易", "立券"],
            ji: ["嫁娶", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "22",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "臘月初四",
            yi: ["入宅", "移徙", "安床"],
            ji: ["作灶", "祭祀"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "23",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "臘月初五",
            yi: ["修造", "動土", "上樑"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "24",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "臘月初六",
            yi: ["嫁娶", "納采", "訂盟"],
            ji: ["開市", "安床"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "25",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "臘月初七",
            yi: ["祭祀", "祈福", "出行"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "26",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "臘月初八",
            yi: ["開市", "交易", "立券"],
            ji: ["出行", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "27",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "臘月初九",
            yi: ["入宅", "安香", "安床"],
            ji: ["修造", "動土"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "28",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "臘月初十",
            yi: ["祭祀", "祈福", "齋醮"],
            ji: ["嫁娶", "開市"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "29",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "臘月十一",
            yi: ["理髮", "沐浴", "作灶"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "30",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "臘月十二",
            yi: ["嫁娶", "訂盟", "納采"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "JAN",
            monthNum: "1",
            dayNum: "31",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "臘月十三",
            yi: ["祭祀", "祈福", "求嗣"],
            ji: ["動土", "破土"],
            solarTerm: nil,
            isHoliday: true
        ),
    ]

    // 2026年 2月 (28天)
    static let februaryDays: [AlmanacDay] = [
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "1",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "臘月十四",
            yi: ["解除", "掃舍", "壞垣"],
            ji: ["餘事勿取"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "2",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "臘月十五",
            yi: ["開市", "交易", "立券"],
            ji: ["嫁娶", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "3",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "臘月十六",
            yi: ["入宅", "移徙", "安床"],
            ji: ["作灶", "祭祀"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "4",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "臘月十七",
            yi: ["修造", "動土", "上樑"],
            ji: ["安葬", "行喪"],
            solarTerm: "立春",
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "5",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "臘月十八",
            yi: ["嫁娶", "納采", "訂盟"],
            ji: ["開市", "安床"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "6",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "臘月十九",
            yi: ["祭祀", "祈福", "出行"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "7",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "臘月二十",
            yi: ["開市", "交易", "立券"],
            ji: ["出行", "移徙"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "8",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "臘月廿一",
            yi: ["入宅", "安香", "安床"],
            ji: ["修造", "動土"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "9",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "臘月廿二",
            yi: ["祭祀", "祈福", "齋醮"],
            ji: ["嫁娶", "開市"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "10",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "臘月廿三",
            yi: ["理髮", "沐浴", "作灶"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "11",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "臘月廿四",
            yi: ["嫁娶", "訂盟", "納采"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "12",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "臘月廿五",
            yi: ["祭祀", "祈福", "求嗣"],
            ji: ["動土", "破土"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "13",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "臘月廿六",
            yi: ["解除", "掃舍", "壞垣"],
            ji: ["餘事勿取"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "14",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "臘月廿七",
            yi: ["開市", "交易", "立券"],
            ji: ["嫁娶", "移徙"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "15",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "臘月廿八",
            yi: ["入宅", "移徙", "安床"],
            ji: ["作灶", "祭祀"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "16",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "臘月廿九",
            yi: ["除服", "成服", "移柩"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "17",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "正月初一",
            yi: ["出行", "拜年", "祭祀"],
            ji: ["動土", "掃舍"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "18",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "正月初二",
            yi: ["回娘家", "祭祀", "祈福"],
            ji: ["洗衣", "動土"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "19",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "正月初三",
            yi: ["祭祀", "解除", "沐浴"],
            ji: ["嫁娶", "開市"],
            solarTerm: "雨水",
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "20",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "正月初四",
            yi: ["接神", "祭祀", "祈福"],
            ji: ["出遠門"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "21",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "正月初五",
            yi: ["開市", "交易", "立券"],
            ji: ["動土", "破土"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "22",
            weekDay: "星期日",
            weekDayEn: "SUNDAY",
            lunarDate: "正月初六",
            yi: ["解除", "掃舍", "壞垣"],
            ji: ["餘事勿取"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "23",
            weekDay: "星期一",
            weekDayEn: "MONDAY",
            lunarDate: "正月初七",
            yi: ["開市", "交易", "立券"],
            ji: ["嫁娶", "移徙"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "24",
            weekDay: "星期二",
            weekDayEn: "TUESDAY",
            lunarDate: "正月初八",
            yi: ["入宅", "移徙", "安床"],
            ji: ["作灶", "祭祀"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "25",
            weekDay: "星期三",
            weekDayEn: "WEDNESDAY",
            lunarDate: "正月初九",
            yi: ["修造", "動土", "上樑"],
            ji: ["安葬", "行喪"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "26",
            weekDay: "星期四",
            weekDayEn: "THURSDAY",
            lunarDate: "正月初十",
            yi: ["嫁娶", "納采", "訂盟"],
            ji: ["開市", "安床"],
            solarTerm: nil,
            isHoliday: false
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "27",
            weekDay: "星期五",
            weekDayEn: "FRIDAY",
            lunarDate: "正月十一",
            yi: ["祭祀", "祈福", "出行"],
            ji: ["開市", "交易"],
            solarTerm: nil,
            isHoliday: true
        ),
        AlmanacDay(
            yearStr: "2026 歲次丙午年",
            monthEn: "FEB",
            monthNum: "2",
            dayNum: "28",
            weekDay: "星期六",
            weekDayEn: "SATURDAY",
            lunarDate: "正月十二",
            yi: ["開市", "交易", "立券"],
            ji: ["出行", "移徙"],
            solarTerm: nil,
            isHoliday: true
        ),
    ]
}

#Preview {
    FarmerCalendarView()
}
