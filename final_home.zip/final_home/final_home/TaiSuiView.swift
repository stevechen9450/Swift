import AlertToast
import Combine
import StoreKit
import SwiftUI

// 商店管理器
@MainActor
class StoreManager: ObservableObject {
    @Published var products: [Product] = []

    // 定義商品 ID
    private let productDict: [ServiceType: String] = [
        .anTaiSui: "yo.antaisui",
        .lightLamp: "yo.light",
    ]

    // 監聽交易更新的任務
    private var updateListenerTask: Task<Void, Error>? = nil

    init() {
        // 1. 初始化時，開始監聽所有交易更新
        updateListenerTask = listenForTransactions()
    }

    deinit {
        updateListenerTask?.cancel()
    }

    // 2. 監聽交易的具體邏輯
    func listenForTransactions() -> Task<Void, Error> {
        return Task.detached {
            // 迴圈監聽 StoreKit 的交易更新流
            for await result in Transaction.updates {
                do {
                    // 因為 checkVerified 已經變成 nonisolated，所以可以在這裡呼叫
                    let transaction = try self.checkVerified(result)

                    // 告訴 Apple 交易完成
                    await transaction.finish()

                    print("✅ 背景監聽收到交易成功: \(transaction.productID)")
                } catch {
                    print("❌ 交易驗證失敗: \(error)")
                }
            }
        }
    }

    // 3. 載入商品資訊
    func loadProducts() async {
        do {
            let productIds = Set(productDict.values)
            self.products = try await Product.products(for: productIds)
            print("成功載入商品: \(self.products.map { $0.displayName })")
        } catch {
            print("載入商品失敗: \(error)")
        }
    }

    // 4. 執行購買
    func purchase(_ type: ServiceType) async throws -> Bool {
        guard let targetProductId = productDict[type],
            let product = products.first(where: { $0.id == targetProductId })
        else {
            print("❌ 錯誤：找不到商品 ID \(type)")
            return false
        }

        print("🚀 開始購買流程：\(product.displayName)")

        do {
            let result = try await product.purchase()

            switch result {
            case .success(let verification):
                print("✅ 購買成功！正在驗證憑證...")
                let transaction = try checkVerified(verification)
                await transaction.finish()
                print("🎉 交易完成：\(transaction.productID)")
                return true

            case .userCancelled:
                print("⚠️ 使用者取消了付款")
                return false

            case .pending:
                print("⏳ 交易處理中 (Pending)")
                return false

            @unknown default:
                print("❓ 未知狀態")
                return false
            }
        } catch {
            print("❌ 購買過程發生錯誤：\(error.localizedDescription)")
            return false
        }
    }

    // 5. 驗證憑證的輔助函式
    nonisolated func checkVerified<T>(_ result: VerificationResult<T>) throws
        -> T
    {
        // 檢查 JWS 簽章是否有效
        switch result {
        case .unverified:
            throw StoreError.failedVerification
        case .verified(let safe):
            return safe
        }
    }

    // 6. 取得商品
    func getProduct(for type: ServiceType) -> Product? {
        guard let id = productDict[type] else { return nil }
        return products.first(where: { $0.id == id })
    }

    // 自定義錯誤類型
    enum StoreError: Error {
        case failedVerification
    }
}



// MARK: View
struct TaiSuiView: View {
    @AppStorage("serviceHistoryData") private var serviceHistoryData: Data =
        Data()
    @State private var historyRecords: [ServiceHistory] = []
    @State private var selectedTargetYear: Int = 2026
    @State private var queryMethod: QueryMethod = .zodiac
    @State private var selectedZodiac: String = "馬"
    @State private var birthYear: String = ""
    @State private var yearType: YearType = .westernYear
    @State private var queryResult: TaiSuiInfo?
    @State private var showResult: Bool = false
    @State private var showServiceSheet: Bool = false
    @State private var activeServiceType: ServiceType = .lightLamp
    @State private var showSuccessAlert: Bool = false
    @State private var isLampRotating: Bool = false
    @State private var showToast = false

    // 初始化 StoreManager
    @StateObject private var storeManager = StoreManager()

    let zodiacs = ["鼠", "牛", "虎", "兔", "龍", "蛇", "馬", "羊", "猴", "雞", "狗", "豬"]

    func getTaiSuiData(for year: Int) -> [String: String] {
        switch year {
        case 2026: return ["馬": "值太歲", "鼠": "沖太歲", "兔": "破太歲", "牛": "害太歲"]
        case 2027: return ["羊": "值太歲", "牛": "沖太歲", "狗": "破太歲", "鼠": "害太歲"]
        case 2028: return ["猴": "值太歲", "虎": "沖太歲", "蛇": "破太歲", "豬": "害太歲"]
        default: return [:]
        }
    }

    enum QueryMethod: Hashable { case zodiac, birthYear }
    enum YearType: String, CaseIterable {
        case westernYear = "西元"
        case mingguoYear = "民國"
    }

    func loadHistory() {
        if let decoded = try? JSONDecoder().decode(
            [ServiceHistory].self,
            from: serviceHistoryData
        ) {
            historyRecords = decoded
        }
    }

    func addRecord(name: String, type: ServiceType) {
        let newRecord = ServiceHistory(
            type: type,
            personName: name,
            date: Date(),
            year: selectedTargetYear
        )
        historyRecords.insert(newRecord, at: 0)
        if let encoded = try? JSONEncoder().encode(historyRecords) {
            serviceHistoryData = encoded
        }

        showToast = true

        if type == .lightLamp {
            triggerLampEffect()
        }
    }

    func triggerLampEffect() {
        isLampRotating = true
        SoundManager.shared.playBlessingSoundOnce()
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            withAnimation { isLampRotating = false }
        }
    }

    func getZodiacFromYear(_ year: Int) -> String {
        let baseYear = 1900
        let offset = (year - baseYear) % 12
        let adjustedOffset = offset >= 0 ? offset : offset + 12
        return zodiacs[adjustedOffset]
    }

    func performQuery() {
        var zodiac = ""
        var age: Int? = nil
        if queryMethod == .zodiac {
            zodiac = selectedZodiac
            age = nil
        } else {
            guard let year = Int(birthYear) else {
                showResult = false
                return
            }
            var westernYear = year
            if yearType == .mingguoYear { westernYear = year + 1911 }
            zodiac = getZodiacFromYear(westernYear)
            age = 2026 - westernYear + 1
        }
        let conflictType =
            getTaiSuiData(for: selectedTargetYear)[zodiac] ?? "無犯太歲"

        var desc = ""
        switch conflictType {
        case "值太歲": desc = "本命年，運程起伏大，凡事需謹慎"
        case "沖太歲": desc = "正沖太歲，諸事多阻礙，變動較大"
        case "破太歲": desc = "主破財耗損，人際關係需小心"
        case "害太歲": desc = "易犯小人，情緒起伏，需注意健康"
        case "無犯太歲": desc = "恭喜！本年度太歲星君庇佑，平安順利"
        default: desc = ""
        }

        queryResult = TaiSuiInfo(
            zodiac: zodiac,
            conflictType: conflictType,
            age: age,
            description: desc,
            suggestion: conflictType == "無犯太歲" ? "運勢平穩，可點光明燈增添光彩" : "建議安太歲以化解煞氣"
        )
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            showResult = true
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.stone50, Color.stone100],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()
            VStack(spacing: 0) {
                headerView
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 25) {
                        queryMethodToggle
                        inputSection
                        queryButton
                        if showResult, let result = queryResult {
                            resultCard(result: result)
                        }
                        Divider().padding(.vertical)
                        serviceSection
                        historyListSection
                        Spacer(minLength: 100)
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                }
            }
        }
        .onAppear {
            loadHistory()
            // 載入商品資訊
            Task {
                await storeManager.loadProducts()
            }
        }
        .sheet(isPresented: $showServiceSheet) {
            // 傳 storeManager 進去
            SimpleServiceFormSheet(
                serviceType: activeServiceType,
                targetYear: selectedTargetYear,
                storeManager: storeManager,
                onComplete: { name in
                    addRecord(name: name, type: activeServiceType)
                }
            )
        }
        .toast(isPresenting: $showToast) {
            AlertToast(
                displayMode: .hud,
                type: .complete(.green),
                title: "登記成功",
                subTitle: "已為您祈福保平安"
            )
        }
    }

    var headerView: some View {
        ZStack {
            Color.red800.ignoresSafeArea()
            VStack(spacing: 8) {
                Menu {
                    Button("2026 (丙午馬年)") {
                        selectedTargetYear = 2026
                        showResult = false
                    }
                    Button("2027 (丁未羊年)") {
                        selectedTargetYear = 2027
                        showResult = false
                    }
                    Button("2028 (戊申猴年)") {
                        selectedTargetYear = 2028
                        showResult = false
                    }
                } label: {
                    HStack {
                        Text("🏮 \(selectedTargetYear) 年運勢 🏮").font(
                            .system(.title, design: .serif)
                        ).fontWeight(.bold).foregroundColor(.white)
                        Image(systemName: "chevron.down.circle.fill")
                            .foregroundColor(.white.opacity(0.8))
                    }
                }
                Text("太歲 / 光明燈 查詢服務").font(.subheadline).foregroundColor(
                    .white.opacity(0.9)
                )
            }
            .padding(.bottom, 20)
        }
        .frame(height: 100)
    }

    var queryMethodToggle: some View {
        HStack(spacing: 0) {
            ForEach([QueryMethod.zodiac, QueryMethod.birthYear], id: \.self) {
                method in
                Button(action: {
                    withAnimation(.spring(response: 0.3)) {
                        queryMethod = method
                        showResult = false
                    }
                }) {
                    Text(method == .zodiac ? "生肖查詢" : "年份查詢")
                        .fontWeight(.semibold).frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            queryMethod == method ? Color.red700 : Color.clear
                        )
                        .foregroundColor(queryMethod == method ? .white : .gray)
                }
            }
        }
        .background(Color.white).cornerRadius(12).shadow(
            color: .black.opacity(0.08),
            radius: 8,
            x: 0,
            y: 4
        )
    }

    var inputSection: some View {
        VStack(spacing: 15) {
            if queryMethod == .zodiac {
                VStack(alignment: .leading, spacing: 8) {
                    Text("選擇生肖").font(.subheadline).foregroundColor(.secondary)
                    Picker("生肖", selection: $selectedZodiac) {
                        ForEach(zodiacs, id: \.self) { zodiac in
                            Text(zodiac).tag(zodiac)
                        }
                    }
                    .pickerStyle(.menu)
                }
                .padding().background(Color.white).cornerRadius(12).shadow(
                    color: .black.opacity(0.08),
                    radius: 8,
                    x: 0,
                    y: 4
                )
            } else {
                VStack(spacing: 15) {
                    Picker("年份類型", selection: $yearType) {
                        ForEach(YearType.allCases, id: \.self) { type in
                            Text(type.rawValue).tag(type)
                        }
                    }.pickerStyle(.segmented)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("出生年份").font(.subheadline).foregroundColor(
                            .secondary
                        )
                        TextField(
                            yearType == .westernYear ? "例如：1990" : "例如：79",
                            text: $birthYear
                        )
                        .font(.system(size: 22)).padding().background(
                            Color.stone50
                        ).cornerRadius(8)
                    }
                }
                .padding().background(Color.white).cornerRadius(12).shadow(
                    color: .black.opacity(0.08),
                    radius: 8,
                    x: 0,
                    y: 4
                )
            }
        }
    }

    var queryButton: some View {
        Button(action: performQuery) {
            HStack {
                Image(systemName: "magnifyingglass")
                Text("查詢 \(selectedTargetYear) 運勢").fontWeight(.bold)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 16)
            .background(
                LinearGradient(
                    colors: [Color.amber500, Color.amber600],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .foregroundColor(.white).cornerRadius(14).shadow(
                color: Color.amber600.opacity(0.4),
                radius: 10,
                x: 0,
                y: 5
            )
        }
    }

    func resultCard(result: TaiSuiInfo) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("生肖：\(result.zodiac)").font(.title2).fontWeight(.bold)
                    Text(
                        result.age != nil
                            ? "\(selectedTargetYear)年 虛歲 \(result.age!) 歲"
                            : "年份不限"
                    ).font(.subheadline).foregroundColor(.secondary)
                }
                Spacer()
                Text(result.conflictType).font(.title3).fontWeight(.bold)
                    .foregroundColor(
                        result.conflictType == "無犯太歲" ? .green : .red
                    )
                    .padding(.horizontal, 16).padding(.vertical, 8)
                    .background(
                        (result.conflictType == "無犯太歲"
                            ? Color.green : Color.red).opacity(0.15)
                    )
                    .cornerRadius(20)
            }
            Divider()
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top) {
                    Image(systemName: "info.circle.fill").foregroundColor(.gray)
                    Text(result.description)
                }.font(.callout)
                HStack(alignment: .top) {
                    Image(systemName: "lightbulb.fill").foregroundColor(
                        .amber500
                    )
                    Text(result.suggestion).foregroundColor(.primary)
                }.font(.callout)
            }
        }
        .padding(20).background(Color.white).cornerRadius(16).shadow(
            color: .black.opacity(0.1),
            radius: 12,
            x: 0,
            y: 6
        )
    }

    var serviceSection: some View {
        VStack(spacing: 15) {
            Text("祈福服務").font(.headline).frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            HStack(spacing: 15) {
                Button(action: {
                    activeServiceType = .lightLamp
                    showServiceSheet = true
                }) {
                    VStack(spacing: 10) {
                        Image(systemName: "lightbulb.fill").font(
                            .system(size: 32)
                        ).foregroundStyle(Color.amber600)
                            .rotationEffect(
                                .degrees(isLampRotating ? 360 * 5 : 0)
                            )
                            .animation(
                                isLampRotating
                                    ? Animation.linear(duration: 10) : .default,
                                value: isLampRotating
                            )
                        Text("點光明燈").font(.subheadline).fontWeight(.semibold)
                            .foregroundColor(.primary)
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 20)
                    .background(Color.white).cornerRadius(12)
                    .shadow(
                        color: isLampRotating
                            ? Color.amber600.opacity(0.5)
                            : .black.opacity(0.08),
                        radius: isLampRotating ? 15 : 8,
                        x: 0,
                        y: 4
                    )
                }
                Button(action: {
                    activeServiceType = .anTaiSui
                    showServiceSheet = true
                }) {
                    VStack(spacing: 10) {
                        Image(systemName: "hand.raised.fill").font(
                            .system(size: 32)
                        ).foregroundStyle(Color.red700)
                        Text("安太歲").font(.subheadline).fontWeight(.semibold)
                            .foregroundColor(.primary)
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 20)
                    .background(Color.white).cornerRadius(12)
                    .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
                }
            }
        }
    }

    var historyListSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("服務紀錄").font(.headline)
                Spacer()
                if !historyRecords.isEmpty {
                    Text("共 \(historyRecords.count) 筆").font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            if historyRecords.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "doc.text.magnifyingglass").font(
                        .largeTitle
                    ).foregroundColor(.gray.opacity(0.5))
                    Text("尚無服務紀錄").font(.caption).foregroundColor(.secondary)
                }.frame(maxWidth: .infinity).padding(.vertical, 30).background(
                    Color.white.opacity(0.5)
                ).cornerRadius(12)
            } else {
                ForEach(historyRecords) { record in
                    HStack {
                        Circle().fill(
                            record.type == .anTaiSui
                                ? Color.red.opacity(0.1)
                                : Color.orange.opacity(0.1)
                        ).frame(width: 40, height: 40)
                            .overlay(
                                Image(
                                    systemName: record.type == .anTaiSui
                                        ? "hand.raised.fill" : "lightbulb.fill"
                                ).foregroundColor(
                                    record.type == .anTaiSui
                                        ? .red700 : .amber600
                                ).font(.caption)
                            )
                        VStack(alignment: .leading, spacing: 4) {
                            Text(record.type.rawValue).font(.subheadline)
                                .fontWeight(.bold)
                            Text("信眾：\(record.personName)").font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            Text("\(record.year)年").font(.caption2).fontWeight(
                                .bold
                            ).foregroundColor(.gray)
                            Text(
                                record.date.formatted(
                                    date: .numeric,
                                    time: .omitted
                                )
                            ).font(.caption2).foregroundColor(.gray)
                        }
                    }.padding().background(Color.white).cornerRadius(12).shadow(
                        color: .black.opacity(0.03),
                        radius: 2,
                        x: 0,
                        y: 2
                    )
                }
            }
        }
    }
}

// 服務表單
struct SimpleServiceFormSheet: View {
    @Environment(\.dismiss) var dismiss
    let serviceType: ServiceType
    let targetYear: Int
    @ObservedObject var storeManager: StoreManager  // 加入 StoreManager

    var onComplete: (String) -> Void
    @State private var name: String = ""
    @State private var isLoading = false
    @State private var errorMsg: String?

    var body: some View {
        NavigationView {
            Form {
                Section {
                    HStack {
                        Spacer()
                        VStack(spacing: 10) {
                            Image(
                                systemName: serviceType == .anTaiSui
                                    ? "hand.raised.fill" : "lightbulb.fill"
                            ).font(.system(size: 50)).foregroundStyle(
                                serviceType == .anTaiSui
                                    ? Color.red : Color.orange
                            )
                            Text(serviceType.rawValue).font(.title2).fontWeight(
                                .bold
                            )

                            // 從 StoreKit 抓，顯示價格
                            if let product = storeManager.getProduct(
                                for: serviceType
                            ) {
                                Text(product.displayPrice)
                                    .font(.headline)
                                    .foregroundColor(.blue)
                            } else {
                                Text("正在載入價格...")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }

                            Text("祈求 \(targetYear) 年平安").font(.headline)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }.listRowBackground(Color.clear)
                }
                Section("信眾資料") {
                    TextField("請輸入姓名", text: $name)
                    Text("我們將為此姓名進行儀式").font(.caption).foregroundColor(
                        .secondary
                    )
                }
                Section {
                    // 購買按鈕
                    if isLoading {
                        ProgressView("連線 Apple Pay 中...")
                            .frame(maxWidth: .infinity)
                    } else {
                        Button(action: {
                            Task {
                                await processPayment()
                            }
                        }) {
                            HStack {
                                Image(systemName: "apple.logo")
                                Text("Apple Pay 支付與登記")
                            }
                            .frame(maxWidth: .infinity).fontWeight(.semibold)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.black)  // Apple Pay 風格
                        .disabled(
                            name.isEmpty
                                || storeManager.getProduct(for: serviceType)
                                    == nil
                        )
                    }
                }

                if let error = errorMsg {
                    Section {
                        Text(error)
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                }
            }
            .navigationTitle("\(serviceType.rawValue)登記")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
        }
    }

    // 處理付款流程
    func processPayment() async {
        isLoading = true
        errorMsg = nil

        do {
            let success = try await storeManager.purchase(serviceType)
            if success {
                onComplete(name)  // 付款成功才登記
                dismiss()
            } else {
                errorMsg = "付款已取消或失敗"
            }
        } catch {
            errorMsg = "發生錯誤：\(error.localizedDescription)"
        }

        isLoading = false
    }
}
