//
//  legoTests.swift
//  legoTests
//
//  Created by 陳昰佑 on 2025/12/27.
//

import Testing
@testable import lego

struct legoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
