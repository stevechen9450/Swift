import SwiftUI

struct ContentView: View {
    let heads: [String]
    let legs: [String]
    let torso = "default-torso"
    
    init() {
        var tempHeads = ["default-head-front"]
        (1...8).forEach { i in
            tempHeads.append(String(format: "Head%05d", i))
        }
        self.heads = tempHeads
        
        var tempLegs = ["default-legs-0"]
        (1...8).forEach { i in
            tempLegs.append(String(format: "Legs%05d", i))
        }
        self.legs = tempLegs
    }

    @State private var showHeadSelection = false
    @State private var showLegSelection = false
    
    @State private var curHeadIndex = 0
    @State private var curLegsIndex = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack {
                Image(legs[curLegsIndex])
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100)
                    .offset(y: 80)
                    .zIndex(1)
                Image(torso)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300)
                    .zIndex(2)
                Image(heads[curHeadIndex])
                    .resizable()
                    .scaledToFit()
                    .frame(width: 70)
                    .offset(y: -67)
                    .zIndex(3)
            }
            .frame(height: 400)
            
            Spacer()
            
            HStack(spacing: 40) {
                Button {
                    showHeadSelection = true
                } label: {
                    Text("換頭").font(.headline).padding()
                }
                .buttonStyle(.borderedProminent)
                
                Button {
                    showLegSelection = true
                } label: {
                    Text("換腳").font(.headline).padding()
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
            }
            .padding(.bottom, 50)
        }
        .sheet(isPresented: $showHeadSelection) {
            SelectionView(title: "選頭", images: heads, selectedIndex: $curHeadIndex)
        }
        .sheet(isPresented: $showLegSelection) {
            SelectionView(title: "選腳", images: legs, selectedIndex: $curLegsIndex)
        }
    }
}


struct SelectionView: View {
    let title: String
    let images: [String]
    @Binding var selectedIndex: Int
    @State private var tempIndex: Int = 0
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 20) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(height: 80)
                            .padding(4)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(tempIndex == index ? Color.blue : Color.clear, lineWidth: 3)
                            )
                            .onTapGesture {
                                tempIndex = index
                            }
                    }
                }
                .padding()
            }
            .navigationTitle(title)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("確定") {
                        selectedIndex = tempIndex
                        dismiss()
                    }
                }
            }
        }
        .onAppear { tempIndex = selectedIndex }
    }
}

#Preview {
    ContentView()
}
